# RootWebDAV Backend

轻量 arm64 WebDAV 服务端（Magisk/KernelSU/APatch 模块），配套
RootWebDAVController APK 使用。

## 功能

- 开机自动启动 WebDAV（不依赖热点状态；共享目录未就绪时会重试，执行痕迹写
  `/data/adb/rootsmb/runtime/state/boot.marker` 和 `runtime/log/backend.log`）。
- 本地控制守护进程 `bin/rootsmb-ctld`（监听 `127.0.0.1:18080`）：APK 可直连
  模块查询状态/启停 WebDAV，不再依赖 `su` 调用。
- 配置全部保存在 `/data/adb/rootsmb/config.conf`，整文件 AES-256-GCM 加密，
  密钥在 `/data/adb/rootsmb/.config.key`。
- Magisk Action：开启时显示地址/端口/用户名/密码/目录，关闭时只显示已关闭。
- APK：只用于编辑配置并显示热点 IP，不负责启停。

## RPC

`ROOTSMB/1` 协议，入口 `/data/adb/modules/rootsmb/bin/smbctl rpc`：
`status`、`load`、`apply`、`password`、`start`、`stop`、`restart`、
`force-restart`、`logs`、`install-check`、`recover`。

## 文件布局

- `bin/webdavd`：WebDAV 服务端（Go，HTTP Range 支持视频拖动）。
- `bin/rootsmb-crypt`：配置文件加解密工具。
- `bin/rootsmb-ctld`：本地控制中继守护进程（root，开机启动）。
- `lib/backend.sh`：后端逻辑（配置解析、启停、RPC）。
- `service.sh`：开机自启 + 手动 start/stop/restart。
- `action.sh`：Magisk Action 启停并打印信息。
