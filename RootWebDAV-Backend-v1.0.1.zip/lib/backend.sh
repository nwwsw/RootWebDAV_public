#!/system/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later
# Trusted backend library. Configuration is parsed as data; it is never sourced.

LC_ALL=C
export LC_ALL

if [ "${ROOTSMB_TEST_MODE:-0}" = "1" ]; then
  DATA_DIR=${ROOTSMB_TEST_DATA_DIR:?ROOTSMB_TEST_DATA_DIR is required}
  WEBDAVD=${ROOTSMB_TEST_SMBD:-$MODDIR/bin/webdavd}
  CRYPT_BIN=${ROOTSMB_TEST_CRYPT:-$MODDIR/bin/rootsmb-crypt}
  TEST_ALLOWED_ROOT=${ROOTSMB_TEST_ALLOWED_ROOT:?ROOTSMB_TEST_ALLOWED_ROOT is required}
else
  DATA_DIR=/data/adb/rootsmb
  WEBDAVD=$MODDIR/bin/webdavd
  CRYPT_BIN=$MODDIR/bin/rootsmb-crypt
  TEST_ALLOWED_ROOT=
fi

CONFIG_FILE=$DATA_DIR/config.conf
RUNTIME_DIR=$DATA_DIR/runtime
LOG_DIR=$RUNTIME_DIR/log
LOCK_FILE=$RUNTIME_DIR/control.lock
LOCK_DIR=$RUNTIME_DIR/control.lock.d
PRIVATE_DIR=$RUNTIME_DIR/private
PID_DIR=$RUNTIME_DIR/run
STATE_DIR=$RUNTIME_DIR/state
CACHE_DIR=$RUNTIME_DIR/cache
BACKEND_CACHE_FILE=$CACHE_DIR/config.cache
WEBDAV_CONF=$RUNTIME_DIR/webdav.conf
WEBDAV_PASS=$PRIVATE_DIR/webdav.pass
PID_FILE=$PID_DIR/webdavd.pid
CONFIG_KEY=$DATA_DIR/.config.key

DEFAULT_PATH_HEX=2F73746F726167652F656D756C617465642F302F446F776E6C6F6164
DEFAULT_SHARE_HEX=50686F6E655368617265
DEFAULT_USER_HEX=6E77777377
DEFAULT_PASSWORD_HEX=3132333435363738
DEFAULT_BIND_HEX=6175746F
DEFAULT_PORT=8080
DEFAULT_WORKGROUP_HEX=574F524B47524F5550

. "$MODDIR/lib/ntlm.sh"

backend_set_error() {
  BACKEND_ERROR=$1
  return 1
}

backend_error_message() {
  case "$1" in
    E_BAD_REQUEST) printf '%s' 'Malformed request' ;;
    E_BAD_VERSION) printf '%s' 'Unsupported protocol version' ;;
    E_BAD_OPERATION) printf '%s' 'Unsupported operation' ;;
    E_BAD_FIELD) printf '%s' 'Invalid or unexpected field' ;;
    E_TOO_LARGE) printf '%s' 'Request or field is too large' ;;
    E_NOT_ROOT) printf '%s' 'Root permission is required' ;;
    E_BUSY) printf '%s' 'Backend is busy' ;;
    E_CONFIG) printf '%s' 'Configuration is invalid' ;;
    E_CONFIG_PATH) printf '%s' 'Configuration path is not a regular file' ;;
    E_PATH) printf '%s' 'Share path is outside allowed storage or unavailable' ;;
    E_BIND) printf '%s' 'Bind address is invalid or not assigned to a trusted interface' ;;
    E_PORT) printf '%s' 'Port must be a decimal integer from 1 through 65535' ;;
    E_PASSWORD) printf '%s' 'Password is invalid' ;;
    E_PASSWORD_REQUIRED) printf '%s' 'Set a password before starting WebDAV' ;;
    E_BINARY) printf '%s' 'WebDAV server binary is missing or not executable' ;;
    E_FOREIGN_SERVER) printf '%s' 'Another WebDAV server process is already running' ;;
    E_START) printf '%s' 'WebDAV server failed to start' ;;
    E_STOP) printf '%s' 'WebDAV server failed to stop' ;;
    E_IO) printf '%s' 'Secure storage operation failed' ;;
    *) printf '%s' 'Backend operation failed' ;;
  esac
}

backend_json_escape() {
  # awk is used instead of sed because GNU sed interprets '\n' in the
  # replacement as a literal newline, which would leave multi-line values
  # (log snippets, webdav.conf) unescaped and break the one-line JSON contract.
  printf '%s' "$1" | awk '
    {
      gsub(/\\/, "\\\\")
      gsub(/"/, "\\\"")
      gsub(/\t/, "\\t")
      gsub(/\r/, "")
      if (NR > 1) printf "\\n"
      printf "%s", $0
    }'
}

backend_json_error() {
  local code=${1:-E_INTERNAL} message
  message=$(backend_error_message "$code")
  printf '{"ok":false,"code":"%s","message":"%s"}\n' \
    "$code" "$(backend_json_escape "$message")"
}

backend_json_ok() {
  local data
  if [ "$#" -gt 0 ]; then data=$1; else data='{}'; fi
  printf '{"ok":true,"code":"OK","data":%s}\n' "$data"
}

backend_init_layout() {
  umask 077
  mkdir -p "$DATA_DIR" "$RUNTIME_DIR" "$LOG_DIR" "$PRIVATE_DIR" \
    "$PID_DIR" "$STATE_DIR" "$CACHE_DIR" 2>/dev/null || return 1
  chmod 0700 "$DATA_DIR" "$RUNTIME_DIR" "$LOG_DIR" "$PRIVATE_DIR" \
    "$PID_DIR" "$STATE_DIR" "$CACHE_DIR" 2>/dev/null || true
  if [ "${ROOTSMB_TEST_MODE:-0}" != "1" ]; then
    chown 0:0 "$DATA_DIR" "$RUNTIME_DIR" "$LOG_DIR" "$PRIVATE_DIR" \
      "$PID_DIR" "$STATE_DIR" "$CACHE_DIR" 2>/dev/null || return 1
  fi
}

backend_log() {
  # Callers pass constants only. Never include RPC fields or password material.
  local level=$1 event=$2
  backend_init_layout >/dev/null 2>&1 || return 0
  printf '%s component=rootsmb level=%s event=%s\n' \
    "$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null)" "$level" "$event" \
    >> "$LOG_DIR/backend.log" 2>/dev/null || true
}

backend_flock_probe() {
  BACKEND_PROBE_CANDIDATE=$1
  BACKEND_PROBE_RC=1
  case "$BACKEND_PROBE_CANDIDATE" in
    */*) [ -x "${BACKEND_PROBE_CANDIDATE%% *}" ] || return 1 ;;
    *) command -v "${BACKEND_PROBE_CANDIDATE%% *}" >/dev/null 2>&1 || return 1 ;;
  esac
  # The probe must exercise the exact operation used by the critical section:
  # open a descriptor and call `flock -n FD`. A `-c` file-lock probe can report
  # usable on BusyBox builds whose numeric-FD locking is actually broken.
  exec 8>"$BACKEND_FLOCK_PROBE" 2>/dev/null || return 1
  if $BACKEND_PROBE_CANDIDATE -n 8 >/dev/null 2>&1 && \
     $BACKEND_PROBE_CANDIDATE -u 8 >/dev/null 2>&1; then
    BACKEND_FLOCK_CMD=$BACKEND_PROBE_CANDIDATE
    BACKEND_PROBE_RC=0
  fi
  exec 8>&-
  return "$BACKEND_PROBE_RC"
}

backend_flock_capable() {
  BACKEND_FLOCK_CMD=
  BACKEND_FLOCK_RC=1
  BACKEND_FLOCK_PROBE=$RUNTIME_DIR/.flock-probe.$$
  # Android's native toybox generally does not ship flock(1), and a plain
  # `su -c` shell does not inherit the root manager's BusyBox PATH. Probe every
  # implementation we can find: PATH applets, toybox, busybox, then the well
  # known Magisk/KernelSU/APatch BusyBox locations. A real lock/unlock cycle on
  # our own descriptor is required before any flock critical section.
  for BACKEND_FLOCK_CANDIDATE in \
    "$(command -v flock 2>/dev/null)" \
    "$(command -v toybox 2>/dev/null) flock" \
    "$(command -v busybox 2>/dev/null) flock" \
    "/data/adb/magisk/busybox flock" \
    "/data/adb/ksu/bin/busybox flock" \
    "/data/adb/ap/bin/busybox flock" \
    "/system/bin/busybox flock" \
    "/system/xbin/busybox flock" \
    "/vendor/bin/busybox flock" \
    "/sbin/busybox flock"
  do
    [ -n "$BACKEND_FLOCK_CANDIDATE" ] || continue
    if backend_flock_probe "$BACKEND_FLOCK_CANDIDATE"; then
      BACKEND_FLOCK_RC=0
      break
    fi
  done
  rm -f "$BACKEND_FLOCK_PROBE" 2>/dev/null || true
  [ "$BACKEND_FLOCK_RC" -eq 0 ] || BACKEND_FLOCK_CMD=
  return "$BACKEND_FLOCK_RC"
}

backend_lock_dir_cleanup_stale() {
  local stale stale_pid
  for stale in "$RUNTIME_DIR"/control.lock.stale.* "$RUNTIME_DIR"/.control.lock.new.*; do
    [ -d "$stale" ] || continue
    stale_pid=$(cat "$stale/pid" 2>/dev/null) || continue
    case "$stale_pid" in ''|*[!0-9]*) continue ;; esac
    kill -0 "$stale_pid" 2>/dev/null && continue
    rm -rf "$stale" 2>/dev/null || true
  done
}

backend_lock_acquire() {
  BACKEND_ERROR=
  BACKEND_LOCK_TRIES=0
  BACKEND_LOCK_MAX_TRIES=100
  BACKEND_LOCK_TMP=
  BACKEND_LOCK_PID=
  BACKEND_LOCK_QUAR=
  backend_init_layout || { backend_set_error E_IO; return 1; }
  BACKEND_LOCK_KIND=
  if [ "${ROOTSMB_TEST_MODE:-0}" = 1 ]; then
    case "${ROOTSMB_TEST_LOCK_MAX_TRIES:-}" in
      ''|*[!0-9]*|0) ;;
      *) BACKEND_LOCK_MAX_TRIES=$ROOTSMB_TEST_LOCK_MAX_TRIES ;;
    esac
  fi

  # Preferred domain: one canonical kernel flock on control.lock. This keeps
  # the v0.2 behavior when the root manager's BusyBox flock is reachable, and
  # the kernel releases ownership automatically if the process exits.
  if backend_flock_capable; then
    exec 9>"$LOCK_FILE" 2>/dev/null || { backend_set_error E_IO; return 1; }
    while ! $BACKEND_FLOCK_CMD -n 9 >/dev/null 2>&1; do
      BACKEND_LOCK_TRIES=$((BACKEND_LOCK_TRIES + 1))
      if [ "$BACKEND_LOCK_TRIES" -ge "$BACKEND_LOCK_MAX_TRIES" ]; then
        exec 9>&-
        backend_set_error E_BUSY
        return 1
      fi
      sleep 0.1
    done
    BACKEND_LOCK_KIND=flock
    return 0
  fi

  # Fallback domain for hosts without any usable flock(1): an atomic mkdir +
  # rename directory lock. The owner writes its PID before publishing the
  # directory, so a crashed holder is detectable. A stale holder is only
  # removed by one process that wins an atomic recover marker; a live holder is
  # never removed. If a recovery marker is already present it is treated as an
  # in-flight recovery (safe E_BUSY), never raced.
  while :; do
    backend_lock_dir_cleanup_stale
    if [ ! -e "$LOCK_DIR" ]; then
      BACKEND_LOCK_TMP=$RUNTIME_DIR/.control.lock.new.$$.$BACKEND_LOCK_TRIES
      if mkdir "$BACKEND_LOCK_TMP" 2>/dev/null; then
        if printf '%s\n' "$$" > "$BACKEND_LOCK_TMP/pid" 2>/dev/null && \
           mv "$BACKEND_LOCK_TMP" "$LOCK_DIR" 2>/dev/null; then
          BACKEND_LOCK_KIND=dir
          trap 'backend_lock_release' 0 2>/dev/null || true
          return 0
        fi
        rm -rf "$BACKEND_LOCK_TMP" 2>/dev/null || true
      fi
    elif [ -d "$LOCK_DIR" ] && [ ! -L "$LOCK_DIR" ]; then
      if [ -d "$LOCK_DIR/recover" ] && [ ! -L "$LOCK_DIR/recover" ]; then
        : # A recovery is in progress or a janitor died mid-recovery; stay safe.
      else
        BACKEND_LOCK_PID=$(cat "$LOCK_DIR/pid" 2>/dev/null)
        case "$BACKEND_LOCK_PID" in
          ''|*[!0-9]*) : ;;
          *)
            if ! kill -0 "$BACKEND_LOCK_PID" 2>/dev/null; then
              if mkdir "$LOCK_DIR/recover" 2>/dev/null; then
                BACKEND_LOCK_PID=$(cat "$LOCK_DIR/pid" 2>/dev/null)
                if [ -n "$BACKEND_LOCK_PID" ] && [ "$BACKEND_LOCK_PID" -gt 0 ] 2>/dev/null && \
                   ! kill -0 "$BACKEND_LOCK_PID" 2>/dev/null; then
                  BACKEND_LOCK_QUAR=$RUNTIME_DIR/control.lock.stale.$$.$BACKEND_LOCK_TRIES
                  if [ ! -e "$BACKEND_LOCK_QUAR" ] && \
                     mv "$LOCK_DIR" "$BACKEND_LOCK_QUAR" 2>/dev/null; then
                    rm -rf "$BACKEND_LOCK_QUAR" 2>/dev/null || true
                  else
                    rmdir "$LOCK_DIR/recover" 2>/dev/null || true
                  fi
                else
                  rmdir "$LOCK_DIR/recover" 2>/dev/null || true
                fi
              fi
            fi
            ;;
        esac
      fi
    else
      backend_set_error E_IO
      return 1
    fi
    BACKEND_LOCK_TRIES=$((BACKEND_LOCK_TRIES + 1))
    if [ "$BACKEND_LOCK_TRIES" -ge "$BACKEND_LOCK_MAX_TRIES" ]; then
      backend_set_error E_BUSY
      return 1
    fi
    sleep 0.1
  done
}

backend_lock_release() {
  case "${BACKEND_LOCK_KIND:-}" in
    flock) $BACKEND_FLOCK_CMD -u 9 >/dev/null 2>&1 || true; exec 9>&- ;;
    dir) rm -rf "$LOCK_DIR" 2>/dev/null || true ;;
  esac
  BACKEND_LOCK_KIND=
}

backend_hex_valid() {
  local value=$1 max_chars=$2
  [ -n "$value" ] || return 1
  [ "${#value}" -le "$max_chars" ] || return 1
  [ $(( ${#value} % 2 )) -eq 0 ] || return 1
  case "$value" in *[!0-9A-Fa-f]*) return 1 ;; esac
  return 0
}

backend_hex_decode() {
  local input=$1 output
  case "$input" in
    ''|*[!0-9A-Fa-f]*) return 1 ;;
  esac
  [ $(( ${#input} % 2 )) -eq 0 ] || return 1
  case "$input" in
    *00*|*0A*|*0a*|*0D*|*0d*) return 1 ;;
  esac
  output=$(printf '%s' "$input" | xxd -r -p 2>/dev/null) || return 1
  BACKEND_DECODED=$output
}

backend_utf8_valid() {
  ntlm_utf8_to_utf16le "$1" || return 1
  unset NTLM_UTF16_HEX
  return 0
}

backend_hex_has_no_ascii_controls() {
  local input=$1 pair byte
  while [ -n "$input" ]; do
    pair=${input:0:2}
    input=${input:2}
    byte=$((0x$pair))
    [ "$byte" -ge 32 ] && [ "$byte" -ne 127 ] || return 1
  done
}

backend_validate_path_hex_syntax() {
  local value=$1 decoded
  backend_hex_valid "$value" 2048 || return 1
  # Reject every ASCII C0 control and DEL before decoding. Besides being
  # unsuitable in a config path, these bytes cannot be emitted by the
  # deliberately small JSON escaper without producing invalid JSON.
  backend_hex_has_no_ascii_controls "$value" || return 1
  backend_utf8_valid "$value" || return 1
  backend_hex_decode "$value" || return 1
  decoded=$BACKEND_DECODED
  case "$decoded" in
    /*) ;;
    *) return 1 ;;
  esac
  case "$decoded" in
    *'#'*|*';'*|*'['*|*']'*|*'%'*|*'\'*|*'"'*) return 1 ;;
  esac
  [ "${#decoded}" -le 1024 ]
}

backend_validate_share_hex() {
  local value=$1 decoded
  backend_hex_valid "$value" 128 || return 1
  backend_hex_decode "$value" || return 1
  decoded=$BACKEND_DECODED
  case "$decoded" in ''|*[!A-Za-z0-9._-]*) return 1 ;; esac
  # These names have special section semantics and must never become
  # the controller-managed share section (matching is case-insensitive).
  case "$decoded" in
    [Gg][Ll][Oo][Bb][Aa][Ll]|[Hh][Oo][Mm][Ee][Ss]|[Pp][Rr][Ii][Nn][Tt][Ee][Rr][Ss]) return 1 ;;
  esac
  [ "${#decoded}" -le 64 ]
}

backend_validate_user_hex() {
  local value=$1 decoded
  backend_hex_valid "$value" 64 || return 1
  backend_hex_decode "$value" || return 1
  decoded=$BACKEND_DECODED
  case "$decoded" in ''|*[!A-Za-z0-9._-]*) return 1 ;; esac
  [ "${#decoded}" -le 32 ]
}

backend_ipv4_valid() {
  local value=$1 old_ifs part
  case "$value" in ''|*[!0-9.]*|.*|*.|*..*) return 1 ;; esac
  old_ifs=$IFS
  IFS=.
  set -- $value
  IFS=$old_ifs
  [ "$#" -eq 4 ] || return 1
  for part in "$@"; do
    case "$part" in ''|*[!0-9]*) return 1 ;; esac
    [ "${#part}" -le 3 ] || return 1
    case "$part" in 0) ;; 0*) return 1 ;; esac
    [ "$part" -le 255 ] 2>/dev/null || return 1
  done
  return 0
}

backend_validate_bind_hex() {
  local value=$1 decoded
  backend_hex_valid "$value" 30 || return 1
  backend_hex_decode "$value" || return 1
  decoded=$BACKEND_DECODED
  [ "$decoded" = auto ] || backend_ipv4_valid "$decoded"
}

backend_validate_port() {
  local value=$1
  case "$value" in ''|*[!0-9]*) return 1 ;; esac
  [ "${#value}" -le 5 ] || return 1
  case "$value" in 0|0*) return 1 ;; esac
  [ "$value" -ge 1 ] 2>/dev/null && [ "$value" -le 65535 ] 2>/dev/null
}

backend_validate_workgroup_hex() {
  local value=$1 decoded
  backend_hex_valid "$value" 30 || return 1
  backend_hex_decode "$value" || return 1
  decoded=$BACKEND_DECODED
  case "$decoded" in ''|*[!A-Za-z0-9._-]*) return 1 ;; esac
  [ "${#decoded}" -le 15 ]
}

backend_config_defaults() {
  CONFIG_NEEDS_MIGRATION=0
  CFG_PATH_HEX=$DEFAULT_PATH_HEX
  CFG_SHARE_HEX=$DEFAULT_SHARE_HEX
  CFG_USER_HEX=$DEFAULT_USER_HEX
  CFG_READONLY=0
  CFG_AUTOSTART=1
  CFG_BIND_HEX=$DEFAULT_BIND_HEX
  CFG_PORT=$DEFAULT_PORT
  CFG_WORKGROUP_HEX=$DEFAULT_WORKGROUP_HEX
  CFG_PASSWORD_HEX=$DEFAULT_PASSWORD_HEX
  CFG_POLL=2
}

backend_validate_config_syntax() {
  backend_validate_path_hex_syntax "$CFG_PATH_HEX" || return 1
  backend_validate_share_hex "$CFG_SHARE_HEX" || return 1
  backend_validate_user_hex "$CFG_USER_HEX" || return 1
  case "$CFG_READONLY" in 0|1) ;; *) return 1 ;; esac
  case "$CFG_AUTOSTART" in 0|1) ;; *) return 1 ;; esac
  backend_validate_bind_hex "$CFG_BIND_HEX" || return 1
  backend_validate_port "$CFG_PORT" || return 1
  backend_validate_workgroup_hex "$CFG_WORKGROUP_HEX" || return 1
}

backend_config_ensure_key() {
  [ -s "$CONFIG_KEY" ] && return 0
  dd if=/dev/urandom of="$CONFIG_KEY" bs=32 count=1 2>/dev/null || return 1
  chmod 0600 "$CONFIG_KEY" 2>/dev/null || return 1
  if [ "${ROOTSMB_TEST_MODE:-0}" != "1" ]; then
    chown 0:0 "$CONFIG_KEY" 2>/dev/null || return 1
  fi
  [ -s "$CONFIG_KEY" ]
}

backend_write_config() {
  local temp=$DATA_DIR/.config.conf.tmp.$$
  backend_init_layout || return 1
  backend_validate_config_syntax || return 1
  umask 077
  {
    printf '%s\n' 'FORMAT=ROOTSMB2'
    printf 'PATH=%s\n' "$CFG_PATH_HEX"
    printf 'SHARE=%s\n' "$CFG_SHARE_HEX"
    printf 'USER=%s\n' "$CFG_USER_HEX"
    printf 'READONLY=%s\n' "$CFG_READONLY"
    printf 'AUTOSTART=%s\n' "$CFG_AUTOSTART"
    printf 'BIND=%s\n' "$CFG_BIND_HEX"
    printf 'PORT=%s\n' "$CFG_PORT"
    printf 'WORKGROUP=%s\n' "$CFG_WORKGROUP_HEX"
    printf 'PASSWORD=%s\n' "$CFG_PASSWORD_HEX"
    printf 'POLL=%s\n' "$CFG_POLL"
  } > "$temp" || { rm -f "$temp" 2>/dev/null; return 1; }
  chmod 0600 "$temp" 2>/dev/null || { rm -f "$temp" 2>/dev/null; return 1; }
  if [ "${ROOTSMB_TEST_MODE:-0}" != "1" ]; then
    chown 0:0 "$temp" 2>/dev/null || { rm -f "$temp" 2>/dev/null; return 1; }
  fi
  if [ -x "$CRYPT_BIN" ]; then
    backend_config_ensure_key || { rm -f "$temp" 2>/dev/null; backend_set_error E_IO; return 1; }
    ROOTSMB_CRYPT_KEY_FILE=$CONFIG_KEY "$CRYPT_BIN" enc "$temp" "$CONFIG_FILE" 2>/dev/null || {
      rm -f "$temp" 2>/dev/null; backend_set_error E_IO; return 1;
    }
    rm -f "$temp" 2>/dev/null || true
  else
    mv -f "$temp" "$CONFIG_FILE" || { rm -f "$temp" 2>/dev/null; return 1; }
  fi
  return 0
}

backend_parse_config_snapshot() {
  local line key value format_seen=0 path_seen=0 share_seen=0 user_seen=0
  local readonly_seen=0 autostart_seen=0 bind_seen=0 port_seen=0 workgroup_seen=0 password_seen=0 poll_seen=0
  local config_format= snapshot=$1

  CFG_PATH_HEX=
  CFG_SHARE_HEX=
  CFG_USER_HEX=
  CFG_READONLY=
  CFG_AUTOSTART=
  CFG_BIND_HEX=
  CFG_PORT=
  CFG_WORKGROUP_HEX=
  CFG_PASSWORD_HEX=
  CFG_POLL=
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in *=*) ;; *) return 1 ;; esac
    key=${line%%=*}
    value=${line#*=}
    case "$key" in
      FORMAT)
        [ "$format_seen" -eq 0 ] || return 1
        case "$value" in ROOTSMB1|ROOTSMB2) config_format=$value ;; *) return 1 ;; esac
        format_seen=1
        ;;
      PATH)
        [ "$path_seen" -eq 0 ] || return 1
        CFG_PATH_HEX=$value; path_seen=1
        ;;
      SHARE)
        [ "$share_seen" -eq 0 ] || return 1
        CFG_SHARE_HEX=$value; share_seen=1
        ;;
      USER)
        [ "$user_seen" -eq 0 ] || return 1
        CFG_USER_HEX=$value; user_seen=1
        ;;
      READONLY)
        [ "$readonly_seen" -eq 0 ] || return 1
        CFG_READONLY=$value; readonly_seen=1
        ;;
      AUTOSTART)
        [ "$autostart_seen" -eq 0 ] || return 1
        CFG_AUTOSTART=$value; autostart_seen=1
        ;;
      BIND)
        [ "$bind_seen" -eq 0 ] || return 1
        CFG_BIND_HEX=$value; bind_seen=1
        ;;
      PORT)
        [ "$port_seen" -eq 0 ] || return 1
        CFG_PORT=$value; port_seen=1
        ;;
      WORKGROUP)
        [ "$workgroup_seen" -eq 0 ] || return 1
        CFG_WORKGROUP_HEX=$value; workgroup_seen=1
        ;;
      PASSWORD)
        [ "$password_seen" -eq 0 ] || return 1
        CFG_PASSWORD_HEX=$value; password_seen=1
        ;;
      POLL)
        [ "$poll_seen" -eq 0 ] || return 1
        CFG_POLL=$value; poll_seen=1
        ;;
      *) return 1 ;;
    esac
  done < "$snapshot"
  [ "$format_seen" -eq 1 ] && [ "$path_seen" -eq 1 ] && \
    [ "$share_seen" -eq 1 ] && [ "$user_seen" -eq 1 ] && \
    [ "$readonly_seen" -eq 1 ] && [ "$autostart_seen" -eq 1 ] || return 1
  case "$config_format" in
    ROOTSMB1)
      [ "$bind_seen" -eq 0 ] && [ "$port_seen" -eq 0 ] && [ "$workgroup_seen" -eq 0 ] || return 1
      CFG_BIND_HEX=$DEFAULT_BIND_HEX
      CFG_PORT=$DEFAULT_PORT
      CFG_WORKGROUP_HEX=$DEFAULT_WORKGROUP_HEX
      CONFIG_NEEDS_MIGRATION=1
      ;;
    ROOTSMB2)
      [ "$bind_seen" -eq 1 ] && [ "$port_seen" -eq 1 ] && [ "$workgroup_seen" -eq 1 ] || return 1
      CONFIG_NEEDS_MIGRATION=0
      ;;
    *) return 1 ;;
  esac
  if [ -n "$CFG_PASSWORD_HEX" ]; then
    backend_hex_valid "$CFG_PASSWORD_HEX" 2048 || return 1
    backend_utf8_valid "$CFG_PASSWORD_HEX" || return 1
  fi
  if [ -n "$CFG_POLL" ]; then
    case "$CFG_POLL" in ''|*[!0-9]*) return 1 ;; esac
    [ "$CFG_POLL" -ge 1 ] 2>/dev/null && [ "$CFG_POLL" -le 3600 ] 2>/dev/null || return 1
  fi
  backend_validate_config_syntax
}

backend_parse_config_file() {
  local snapshot=$DATA_DIR/.config.conf.read.$$ rc=0
  BACKEND_PARSE_ERROR=
  if [ -e "$snapshot" ] || [ -L "$snapshot" ]; then
    BACKEND_PARSE_ERROR=E_IO
    return 1
  fi
  umask 077
  # Copy through cat (legacy plaintext) or decrypt through rootsmb-crypt
  # while holding the backend lock. Only a completed read is eligible for
  # syntax classification; open/read/write/decrypt failure remains E_IO and
  # can never authorize installer quarantine.
  if head -c 11 "$CONFIG_FILE" 2>/dev/null | grep -q '^ROOTSMBENC1'; then
    if [ -x "$CRYPT_BIN" ] && [ -s "$CONFIG_KEY" ]; then
      ROOTSMB_CRYPT_KEY_FILE=$CONFIG_KEY "$CRYPT_BIN" dec "$CONFIG_FILE" "$snapshot" 2>/dev/null || {
        rm -f "$snapshot" 2>/dev/null || true
        BACKEND_PARSE_ERROR=E_IO
        return 1
      }
    else
      rm -f "$snapshot" 2>/dev/null || true
      BACKEND_PARSE_ERROR=E_IO
      return 1
    fi
  elif ! cat "$CONFIG_FILE" > "$snapshot" 2>/dev/null; then
    rm -f "$snapshot" 2>/dev/null || true
    BACKEND_PARSE_ERROR=E_IO
    return 1
  fi
  if ! chmod 0600 "$snapshot" 2>/dev/null; then
    rm -f "$snapshot" 2>/dev/null || true
    BACKEND_PARSE_ERROR=E_IO
    return 1
  fi
  if ! backend_parse_config_snapshot "$snapshot"; then
    BACKEND_PARSE_ERROR=E_CONFIG
    rc=1
  fi
  if ! rm -f "$snapshot" 2>/dev/null; then
    BACKEND_PARSE_ERROR=E_IO
    return 1
  fi
  return "$rc"
}

backend_config_preflight() {
  BACKEND_CONFIG_EXISTS=0
  if [ -e "$CONFIG_FILE" ] || [ -L "$CONFIG_FILE" ]; then
    # Never open a directory, FIFO, device, socket, or symlink as configuration.
    # The test and the later read both happen while the canonical mutation gate
    # is held; non-root callers cannot replace entries in the 0700 data dir.
    if [ ! -f "$CONFIG_FILE" ] || [ -L "$CONFIG_FILE" ]; then
      backend_set_error E_CONFIG_PATH
      return 1
    fi
    BACKEND_CONFIG_EXISTS=1
  fi
  return 0
}

backend_load_config_cache() {
  local stat header key value
  stat=$(stat -c %Y "$CONFIG_FILE" 2>/dev/null) || return 1
  [ -n "$stat" ] || return 1
  [ -f "$BACKEND_CACHE_FILE" ] || return 1
  IFS= read -r header < "$BACKEND_CACHE_FILE" || return 1
  [ "$header" = "stat=$stat" ] || return 1
  BACKEND_CONFIG_EXISTS=1
  BACKEND_CONFIG_CACHED=1
  while IFS= read -r line; do
    case "$line" in
      ''|\#*) continue ;;
      *=*)
        key=${line%%=*}
        value=${line#*=}
        case "$key" in
          path) CFG_PATH=$value ;;
          share) CFG_SHARE=$value ;;
          user) CFG_USER=$value ;;
          bind) CFG_BIND=$value ;;
          workgroup) CFG_WORKGROUP=$value ;;
          password_hex) CFG_PASSWORD_HEX=$value ;;
          readonly) CFG_READONLY=$value ;;
          autostart) CFG_AUTOSTART=$value ;;
          port) CFG_PORT=$value ;;
          poll) CFG_POLL=$value ;;
        esac
        ;;
    esac
  done < "$BACKEND_CACHE_FILE"
  return 0
}

backend_save_config_cache() {
  local stat
  stat=$(stat -c %Y "$CONFIG_FILE" 2>/dev/null) || return 1
  {
    printf 'stat=%s\n' "$stat"
    printf 'path=%s\n' "$CFG_PATH"
    printf 'share=%s\n' "$CFG_SHARE"
    printf 'user=%s\n' "$CFG_USER"
    printf 'bind=%s\n' "$CFG_BIND"
    printf 'workgroup=%s\n' "$CFG_WORKGROUP"
    printf 'password_hex=%s\n' "$CFG_PASSWORD_HEX"
    printf 'readonly=%s\n' "$CFG_READONLY"
    printf 'autostart=%s\n' "$CFG_AUTOSTART"
    printf 'port=%s\n' "$CFG_PORT"
    printf 'poll=%s\n' "$CFG_POLL"
  } > "$BACKEND_CACHE_FILE.tmp.$$" 2>/dev/null && mv "$BACKEND_CACHE_FILE.tmp.$$" "$BACKEND_CACHE_FILE" 2>/dev/null
  rm -f "$BACKEND_CACHE_FILE.tmp.$$" 2>/dev/null || true
  return 0
}

backend_load_config_nolock() {
  local rc=0 code=
  BACKEND_CONFIG_CACHED=0
  BACKEND_ERROR=
  backend_init_layout || { backend_set_error E_IO; return 1; }
  backend_config_defaults
  if backend_load_config_cache; then
    return 0
  fi
  if ! backend_config_preflight; then
    rc=1
  elif [ "$BACKEND_CONFIG_EXISTS" -eq 0 ]; then
    if ! backend_write_config; then backend_set_error E_IO; rc=1; fi
  elif ! backend_parse_config_file; then
    backend_set_error "${BACKEND_PARSE_ERROR:-E_CONFIG}"
    rc=1
  elif [ "${CONFIG_NEEDS_MIGRATION:-0}" = 1 ]; then
    if backend_write_config; then
      CONFIG_NEEDS_MIGRATION=0
    else
      backend_set_error E_IO
      rc=1
    fi
  fi
  if [ "$rc" -eq 0 ]; then
    backend_decode_config || { backend_set_error E_CONFIG; return 1; }
    backend_save_config_cache
  fi
  code=${BACKEND_ERROR:-}
  BACKEND_ERROR=$code
  return "$rc"
}

backend_load_config() {
  local own_lock=0 rc=0 code=
  BACKEND_ERROR=
  backend_init_layout || { backend_set_error E_IO; return 1; }
  backend_config_defaults
  if [ -z "${BACKEND_LOCK_KIND:-}" ]; then
    backend_lock_acquire || return 1
    own_lock=1
  fi
  if ! backend_config_preflight; then
    rc=1
  elif [ "$BACKEND_CONFIG_EXISTS" -eq 0 ]; then
    if ! backend_write_config; then backend_set_error E_IO; rc=1; fi
  elif ! backend_parse_config_file; then
    backend_set_error "${BACKEND_PARSE_ERROR:-E_CONFIG}"
    rc=1
  elif [ "${CONFIG_NEEDS_MIGRATION:-0}" = 1 ]; then
    # The legacy file has already passed the strict six-field parser. Rewriting
    # while holding the mutation lock prevents a stale migration from racing an
    # apply operation.
    if backend_write_config; then
      CONFIG_NEEDS_MIGRATION=0
    else
      backend_set_error E_IO
      rc=1
    fi
  fi
  code=${BACKEND_ERROR:-}
  [ "$own_lock" -eq 0 ] || backend_lock_release
  BACKEND_ERROR=$code
  return "$rc"
}

backend_recover_config() {
  local rejected
  BACKEND_ERROR=
  BACKEND_RECOVERY_QUARANTINED=false
  BACKEND_RECOVERY_BACKUP_NAME=
  [ -n "${BACKEND_LOCK_KIND:-}" ] || { backend_set_error E_BUSY; return 1; }
  backend_init_layout || { backend_set_error E_IO; return 1; }
  backend_config_defaults
  backend_config_preflight || return 1

  if [ "$BACKEND_CONFIG_EXISTS" -eq 0 ]; then
    backend_write_config || { backend_set_error E_IO; return 1; }
    return 0
  fi

  # Re-parse the current inode while holding the lock. If another installer
  # replaced the previously rejected bytes with valid configuration before we
  # acquired the lock, preserve that valid file and report no quarantine.
  if backend_parse_config_file; then
    if [ "${CONFIG_NEEDS_MIGRATION:-0}" = 1 ]; then
      backend_write_config || { backend_set_error E_IO; return 1; }
      CONFIG_NEEDS_MIGRATION=0
    fi
    return 0
  fi
  if [ "${BACKEND_PARSE_ERROR:-E_CONFIG}" != E_CONFIG ]; then
    backend_set_error "${BACKEND_PARSE_ERROR:-E_IO}"
    return 1
  fi

  BACKEND_RECOVERY_BACKUP_NAME=config.conf.rejected-v051-$$
  rejected=$DATA_DIR/$BACKEND_RECOVERY_BACKUP_NAME
  if [ -e "$rejected" ] || [ -L "$rejected" ]; then
    backend_set_error E_IO
    return 1
  fi
  chmod 0600 "$CONFIG_FILE" 2>/dev/null || { backend_set_error E_IO; return 1; }
  if [ "${ROOTSMB_TEST_MODE:-0}" != 1 ]; then
    chown 0:0 "$CONFIG_FILE" 2>/dev/null || { backend_set_error E_IO; return 1; }
  fi
  mv "$CONFIG_FILE" "$rejected" 2>/dev/null || { backend_set_error E_IO; return 1; }
  backend_config_defaults
  backend_write_config || { backend_set_error E_IO; return 1; }
  BACKEND_RECOVERY_QUARANTINED=true
  return 0
}

backend_decode_config() {
  backend_hex_decode "$CFG_PATH_HEX" || return 1; CFG_PATH=$BACKEND_DECODED
  backend_hex_decode "$CFG_SHARE_HEX" || return 1; CFG_SHARE=$BACKEND_DECODED
  backend_hex_decode "$CFG_USER_HEX" || return 1; CFG_USER=$BACKEND_DECODED
  backend_hex_decode "$CFG_BIND_HEX" || return 1; CFG_BIND=$BACKEND_DECODED
  backend_hex_decode "$CFG_WORKGROUP_HEX" || return 1; CFG_WORKGROUP=$BACKEND_DECODED
}

backend_resolve_share_path() {
  local configured=$1 candidate volume resolved allowed
  case "$configured" in
    /) return 1 ;;
    *'/../'*|*/..|../*|..) return 1 ;;
  esac

  if [ "${ROOTSMB_TEST_MODE:-0}" = "1" ]; then
    candidate=$configured
    allowed=$(CDPATH= cd "$TEST_ALLOWED_ROOT" 2>/dev/null && pwd -P) || return 1
    resolved=$(CDPATH= cd "$candidate" 2>/dev/null && pwd -P) || return 1
    case "$resolved" in "$allowed"|"$allowed"/*) ;; *) return 1 ;; esac
    EFFECTIVE_PATH=$resolved
    return 0
  fi

  case "$configured" in
    /sdcard) candidate=/data/media/0 ;;
    /sdcard/*) candidate=/data/media/0/${configured#/sdcard/} ;;
    /storage/emulated/0) candidate=/data/media/0 ;;
    /storage/emulated/0/*) candidate=/data/media/0/${configured#/storage/emulated/0/} ;;
    /data/media/0|/data/media/0/*) candidate=$configured ;;
    /storage/*)
      volume=${configured#/storage/}; volume=${volume%%/*}
      case "$volume" in ''|emulated|self|*[!A-Za-z0-9._-]*) return 1 ;; esac
      case "$configured" in /storage/"$volume") candidate=/mnt/media_rw/$volume ;;
        *) candidate=/mnt/media_rw/$volume/${configured#/storage/$volume/} ;;
      esac
      ;;
    /mnt/media_rw/*) candidate=$configured ;;
    *) return 1 ;;
  esac

  resolved=$(CDPATH= cd "$candidate" 2>/dev/null && pwd -P) || return 1
  case "$resolved" in
    /data/media/0|/data/media/0/*) ;;
    /mnt/media_rw/*)
      volume=${resolved#/mnt/media_rw/}; volume=${volume%%/*}
      case "$volume" in ''|*[!A-Za-z0-9._-]*) return 1 ;; esac
      ;;
    *) return 1 ;;
  esac
  EFFECTIVE_PATH=$resolved
}

backend_webdav_password() {
  # WebDAV basic auth needs the plaintext password. The default is 12345678
  # until the controller updates it through the password RPC; the value comes
  # from the config, with webdav.pass as a legacy fallback.
  BACKEND_WEBDAV_PASS=12345678
  if [ -n "${CFG_PASSWORD_HEX:-}" ]; then
    if backend_hex_decode "$CFG_PASSWORD_HEX"; then
      case "$BACKEND_DECODED" in '') ;; *) BACKEND_WEBDAV_PASS=$BACKEND_DECODED ;; esac
      unset BACKEND_DECODED
    fi
  elif [ -s "$WEBDAV_PASS" ]; then
    BACKEND_WEBDAV_PASS=$(cat "$WEBDAV_PASS" 2>/dev/null)
    case "$BACKEND_WEBDAV_PASS" in '') BACKEND_WEBDAV_PASS=12345678 ;; esac
  fi
  return 0
}

backend_password_set() {
  [ -n "${CFG_PASSWORD_HEX:-}" ] || [ -s "$WEBDAV_PASS" ]
}

backend_select_binding() {
  # auto needs no address at start time: webdavd binds 0.0.0.0 and becomes
  # reachable as soon as the hotspot/Wi-Fi interface gets an IP. A specific
  # address must still be assigned to a trusted interface.
  if [ "$CFG_BIND" = auto ]; then
    return 0
  fi
  local addresses
  addresses=$(backend_addresses) || { backend_set_error E_BIND; return 1; }
  backend_ipv4_valid "$CFG_BIND" || { backend_set_error E_BIND; return 1; }
  case ",$addresses," in
    *,"$CFG_BIND",*) ;;
    *) backend_set_error E_BIND; return 1 ;;
  esac
  return 0
}

backend_write_webdav_conf() {
  local temp=$RUNTIME_DIR/.webdav.conf.tmp.$$
  backend_load_config || return 1
  backend_decode_config || { backend_set_error E_CONFIG; return 1; }
  backend_resolve_share_path "$CFG_PATH" || { backend_set_error E_PATH; return 1; }
  backend_webdav_password || { backend_set_error E_PASSWORD_REQUIRED; return 1; }
  backend_select_binding || return 1

  umask 077
  cat > "$temp" <<EOF
# RootSmb WebDAV configuration (diagnostics only; the server receives its
# settings through environment variables at launch time).
PORT=$CFG_PORT
USER=$CFG_USER
ROOT=$EFFECTIVE_PATH
BIND=$CFG_BIND
EOF
  chmod 0600 "$temp" 2>/dev/null || { rm -f "$temp"; return 1; }
  if [ "${ROOTSMB_TEST_MODE:-0}" != "1" ]; then
    chown 0:0 "$temp" 2>/dev/null || { rm -f "$temp"; return 1; }
  fi
  mv -f "$temp" "$WEBDAV_CONF" || { rm -f "$temp"; return 1; }
}

backend_read_pid() {
  local pid cmd
  pid=$(cat "$PID_FILE" 2>/dev/null)
  case "$pid" in ''|*[!0-9]*) return 1 ;; esac
  kill -0 "$pid" 2>/dev/null || return 1
  if [ "${ROOTSMB_TEST_MODE:-0}" = "1" ]; then
    BACKEND_PID=$pid
    return 0
  fi
  cmd=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
  case "$cmd" in *"$WEBDAV_CONF"*|*"$WEBDAVD"*|*webdavd*) BACKEND_PID=$pid; return 0 ;; esac
  return 1
}

backend_is_running() {
  backend_read_pid
}

backend_foreign_webdav_running() {
  local pid
  command -v pidof >/dev/null 2>&1 || return 1
  for pid in $(pidof webdavd 2>/dev/null); do
    case "$pid" in ''|*[!0-9]*) continue ;; esac
    return 0
  done
  return 1
}

backend_start() {
  local attempt rc launch_pid launch_retried
  BACKEND_ERROR=
  backend_is_running && return 0
  [ -x "$WEBDAVD" ] || backend_set_error E_BINARY || return 1
  if backend_foreign_webdav_running; then
    backend_set_error E_FOREIGN_SERVER
    return 1
  fi
  if ! backend_load_config; then
    [ -n "${BACKEND_ERROR:-}" ] || backend_set_error E_CONFIG
    return 1
  fi
  backend_decode_config || backend_set_error E_CONFIG || return 1
  backend_resolve_share_path "$CFG_PATH" || backend_set_error E_PATH || return 1
  backend_webdav_password || backend_set_error E_PASSWORD_REQUIRED || return 1
  if ! backend_write_webdav_conf; then
    [ -n "${BACKEND_ERROR:-}" ] || backend_set_error E_CONFIG
    return 1
  fi

  rm -rf "$RUNTIME_DIR/lock" "$RUNTIME_DIR/ncalrpc" 2>/dev/null || true
  mkdir -p "$RUNTIME_DIR/lock" "$RUNTIME_DIR/ncalrpc" 2>/dev/null || true
  chmod 0700 "$RUNTIME_DIR/lock" "$RUNTIME_DIR/ncalrpc" 2>/dev/null || true
  launch_pid=
  launch_retried=0
  start_tries=50
  if [ "${ROOTSMB_TEST_MODE:-0}" = "1" ]; then
    start_tries=${ROOTSMB_TEST_START_TRIES:-12}
  fi
  if [ "${ROOTSMB_TEST_MODE:-0}" = "1" ]; then
    ROOTSMB_FAKE_PIDFILE=$PID_FILE "$WEBDAVD" -D -s "$WEBDAV_CONF" \
      >> "$LOG_DIR/webdavd.stdout.log" 2>> "$LOG_DIR/webdavd.stderr.log" 9>&- &
    launch_pid=$!
  elif command -v setsid >/dev/null 2>&1; then
    backend_log INFO SETSID_USED
    ROOTSMB_WEBDAV_PORT="$CFG_PORT" ROOTSMB_WEBDAV_USER="$CFG_USER" \
      ROOTSMB_WEBDAV_PASS="$BACKEND_WEBDAV_PASS" ROOTSMB_WEBDAV_ROOT="$EFFECTIVE_PATH" \
      ROOTSMB_WEBDAV_READONLY="$CFG_READONLY" ROOTSMB_WEBDAV_PIDFILE="$PID_FILE" setsid "$WEBDAVD" \
      >> "$LOG_DIR/webdavd.stdout.log" 2>> "$LOG_DIR/webdavd.stderr.log" 9>&- &
    launch_pid=$!
  else
    backend_log INFO SETSID_MISSING
    ROOTSMB_WEBDAV_PORT="$CFG_PORT" ROOTSMB_WEBDAV_USER="$CFG_USER" \
      ROOTSMB_WEBDAV_PASS="$BACKEND_WEBDAV_PASS" ROOTSMB_WEBDAV_ROOT="$EFFECTIVE_PATH" \
      ROOTSMB_WEBDAV_READONLY="$CFG_READONLY" ROOTSMB_WEBDAV_PIDFILE="$PID_FILE" "$WEBDAVD" \
      >> "$LOG_DIR/webdavd.stdout.log" 2>> "$LOG_DIR/webdavd.stderr.log" 9>&- &
    launch_pid=$!
  fi
  sleep 0.2
  if kill -0 "$launch_pid" 2>/dev/null; then
    backend_log INFO "LAUNCH_ALIVE_${launch_pid}"
  else
    wait "$launch_pid" 2>/dev/null
    rc=$?
    backend_log ERROR "LAUNCH_DIED_RC_${rc}"
    # A broken setsid wrapper can kill the child; retry once without it.
    if [ "${ROOTSMB_TEST_MODE:-0}" != "1" ] && [ "$launch_retried" -eq 0 ] && [ "$rc" -ne 0 ]; then
      launch_retried=1
      backend_log INFO RETRY_NO_SETSID
      ROOTSMB_WEBDAV_PORT="$CFG_PORT" ROOTSMB_WEBDAV_USER="$CFG_USER" \
        ROOTSMB_WEBDAV_PASS="$BACKEND_WEBDAV_PASS" ROOTSMB_WEBDAV_ROOT="$EFFECTIVE_PATH" \
        ROOTSMB_WEBDAV_READONLY="$CFG_READONLY" ROOTSMB_WEBDAV_PIDFILE="$PID_FILE" "$WEBDAVD" \
        >> "$LOG_DIR/webdavd.stdout.log" 2>> "$LOG_DIR/webdavd.stderr.log" 9>&- &
      launch_pid=$!
      sleep 0.2
      if kill -0 "$launch_pid" 2>/dev/null; then
        backend_log INFO "LAUNCH_ALIVE_${launch_pid}"
      else
        wait "$launch_pid" 2>/dev/null
        rc=$?
        backend_log ERROR "LAUNCH_DIED_RC_${rc}"
      fi
    fi
  fi
  attempt=0
  while [ "$attempt" -lt "$start_tries" ]; do
    if backend_is_running; then backend_log INFO STARTED; return 0; fi
    sleep 0.1
    attempt=$((attempt + 1))
  done
  pidfile_pid=$(cat "$PID_FILE" 2>/dev/null)
  case "$pidfile_pid" in
    ''|*[!0-9]*)
      backend_log ERROR "START_TIMEOUT_PIDFILE_INVALID_${pidfile_pid}"
      ;;
    *)
      if kill -0 "$pidfile_pid" 2>/dev/null; then
        # The daemon is up even if its argv was scrubbed; accept it.
        BACKEND_PID=$pidfile_pid
        backend_log INFO "STARTED_VIA_PIDFILE_${pidfile_pid}"
        backend_log INFO STARTED
        return 0
      else
        backend_log ERROR "START_TIMEOUT_PID_DEAD_${pidfile_pid}"
      fi
      ;;
  esac
  if kill -0 "$launch_pid" 2>/dev/null; then
    # Foreground mode: the launched process is the server itself.
    BACKEND_PID=$launch_pid
    printf '%s\n' "$launch_pid" > "$PID_FILE" 2>/dev/null || true
    backend_log INFO "STARTED_VIA_LAUNCH_PID_${launch_pid}"
    backend_log INFO STARTED
    return 0
  else
    wait "$launch_pid" 2>/dev/null
    rc=$?
    backend_log ERROR "START_TIMEOUT_LAUNCH_EXIT_RC_${rc}"
  fi
  backend_log ERROR "WEBDAVD_PS_COUNT_$(ps -A 2>/dev/null | grep -c '[w]ebdavd')"
  portline=$( { netstat -tlnp 2>/dev/null || ss -tlnp 2>/dev/null; } | grep ":$CFG_PORT " | head -n 3)
  [ -n "$portline" ] && backend_log ERROR "PORT${CFG_PORT}_$(printf '%s' "$portline" | tr '\n' ' ')"
  backend_set_error E_START
  backend_log ERROR START_TIMEOUT
  return 1
}

backend_stop() {
  local pid attempt stop_tries
  BACKEND_ERROR=
  if ! backend_read_pid; then
    rm -f "$PID_FILE" 2>/dev/null
    return 0
  fi
  pid=$BACKEND_PID
  stop_tries=50
  if [ "${ROOTSMB_TEST_MODE:-0}" = "1" ]; then
    stop_tries=${ROOTSMB_TEST_STOP_TRIES:-12}
  fi
  kill "$pid" 2>/dev/null || { backend_set_error E_STOP; return 1; }
  attempt=0
  while kill -0 "$pid" 2>/dev/null && [ "$attempt" -lt "$stop_tries" ]; do
    sleep 0.1
    attempt=$((attempt + 1))
  done
  if kill -0 "$pid" 2>/dev/null; then
    kill -9 "$pid" 2>/dev/null || { backend_set_error E_STOP; return 1; }
  fi
  rm -f "$PID_FILE" 2>/dev/null
  backend_log INFO STOPPED
  return 0
}

backend_restart() {
  backend_stop || return 1
  backend_start
}

backend_force_kill_stale() {
  local proc pid cmd first ancestor ppid
  # Never kill this process or its ancestors: the su -> sh chain that
  # started this RPC has "smbctl rpc" in its own cmdline too.
  BACKEND_KILL_ANCESTORS=
  ancestor=$$
  while :; do
    ppid=$(sed -n 's/^[^)]*) \([0-9][0-9]*\).*/\1/p' "/proc/$ancestor/stat" 2>/dev/null)
    case "$ppid" in ''|*[!0-9]*|0|1) break ;; esac
    [ "$ppid" = "$ancestor" ] && break
    BACKEND_KILL_ANCESTORS="$BACKEND_KILL_ANCESTORS $ppid"
    ancestor=$ppid
  done
  # Kill stale controller RPC shells, including orphans of a killed su
  # process, so a stuck flock or directory-lock holder cannot keep the
  # backend busy forever. Only shell/toybox/busybox processes whose
  # cmdline names the backend RPC are targeted; the su wrapper itself
  # (argv[0]="su") is never a target.
  for proc in /proc/[0-9]*; do
    pid=${proc#/proc/}
    case "$pid" in ''|*[!0-9]*) continue ;; esac
    [ "$pid" = "$$" ] && continue
    case " $BACKEND_KILL_ANCESTORS " in *" $pid "*) continue ;; esac
    cmd=$(tr '\000' ' ' < "$proc/cmdline" 2>/dev/null) || continue
    case "$cmd" in
      *smbctl*rpc*|*rpc*smbctl*)
        first=${cmd%% *}
        case "$first" in
          *sh|*toybox|*busybox) kill -9 "$pid" 2>/dev/null || true ;;
        esac
        ;;
    esac
  done
  return 0
}

backend_force_restart() {
  local proc pid cmd
  BACKEND_ERROR=
  backend_force_kill_stale
  # Kill any webdavd or test server bound to this backend, even one that
  # never published a pid file.
  for proc in /proc/[0-9]*; do
    pid=${proc#/proc/}
    case "$pid" in ''|*[!0-9]*) continue ;; esac
    cmd=$(tr '\000' ' ' < "$proc/cmdline" 2>/dev/null) || continue
    case "$cmd" in
      *"$WEBDAV_CONF"*|*webdavd*) kill -9 "$pid" 2>/dev/null || true ;;
    esac
  done
  # Lock artifacts are removed only after every stale RPC holder is dead.
  rm -f "$LOCK_FILE" 2>/dev/null || true
  rm -rf "$LOCK_DIR" 2>/dev/null || true
  backend_init_layout || { backend_set_error E_IO; return 1; }
  rm -f "$PID_FILE" 2>/dev/null || true
  backend_lock_acquire || return 1
  if ! backend_stop; then backend_lock_release; return 1; fi
  if ! backend_start; then backend_lock_release; return 1; fi
  backend_lock_release
  backend_log INFO FORCE_RESTARTED
  return 0
}

backend_install_password() {
  local password_hex=$1 old_hex was_running=0
  BACKEND_ERROR=
  backend_hex_valid "$password_hex" 1024 || backend_set_error E_PASSWORD || return 1
  [ "${#password_hex}" -ge 16 ] || backend_set_error E_PASSWORD || return 1
  backend_utf8_valid "$password_hex" || backend_set_error E_PASSWORD || return 1
  backend_init_layout || backend_set_error E_IO || return 1
  if ! backend_load_config; then
    [ -n "${BACKEND_ERROR:-}" ] || backend_set_error E_CONFIG
    return 1
  fi
  backend_is_running && was_running=1

  old_hex=$CFG_PASSWORD_HEX
  CFG_PASSWORD_HEX=$password_hex
  unset password_hex REQ_PASSWORD NTLM_UTF16_HEX
  if ! backend_write_config; then
    CFG_PASSWORD_HEX=$old_hex
    backend_set_error E_IO
    return 1
  fi

  if [ "$was_running" -eq 1 ] && ! backend_restart; then
    CFG_PASSWORD_HEX=$old_hex
    backend_write_config >/dev/null 2>&1 || true
    backend_start >/dev/null 2>&1 || true
    backend_set_error E_START
    return 1
  fi
  unset old_hex
  backend_log INFO PASSWORD_UPDATED
  return 0
}

backend_apply_config() {
  local old_path old_share old_user old_readonly old_autostart
  local old_bind old_port old_workgroup old_poll was_running=0
  BACKEND_ERROR=
  backend_validate_share_hex "$REQ_SHARE" || backend_set_error E_BAD_FIELD || return 1
  backend_validate_user_hex "$REQ_USER" || backend_set_error E_BAD_FIELD || return 1
  case "$REQ_READONLY" in 0|1) ;; *) backend_set_error E_BAD_FIELD; return 1 ;; esac
  case "$REQ_AUTOSTART" in 0|1) ;; *) backend_set_error E_BAD_FIELD; return 1 ;; esac
  if [ "$SEEN_BIND" -eq 1 ]; then
    backend_validate_bind_hex "$REQ_BIND" || { backend_set_error E_BIND; return 1; }
  fi
  if [ "$SEEN_PORT" -eq 1 ]; then
    backend_validate_port "$REQ_PORT" || { backend_set_error E_PORT; return 1; }
  fi
  if [ "$SEEN_WORKGROUP" -eq 1 ]; then
    backend_validate_workgroup_hex "$REQ_WORKGROUP" || { backend_set_error E_BAD_FIELD; return 1; }
  fi
  if [ "$SEEN_POLL" -eq 1 ]; then
    case "$REQ_POLL" in ''|*[!0-9]*) backend_set_error E_BAD_FIELD; return 1 ;; esac
    [ "$REQ_POLL" -ge 1 ] 2>/dev/null && [ "$REQ_POLL" -le 3600 ] 2>/dev/null || { backend_set_error E_BAD_FIELD; return 1; }
  fi
  backend_validate_path_hex_syntax "$REQ_PATH" || backend_set_error E_BAD_FIELD || return 1

  backend_hex_decode "$REQ_PATH" || backend_set_error E_BAD_FIELD || return 1
  backend_resolve_share_path "$BACKEND_DECODED" || backend_set_error E_PATH || return 1
  if ! backend_load_config; then
    [ -n "${BACKEND_ERROR:-}" ] || backend_set_error E_CONFIG
    return 1
  fi
  old_path=$CFG_PATH_HEX; old_share=$CFG_SHARE_HEX; old_user=$CFG_USER_HEX
  old_readonly=$CFG_READONLY; old_autostart=$CFG_AUTOSTART
  old_bind=$CFG_BIND_HEX; old_port=$CFG_PORT; old_workgroup=$CFG_WORKGROUP_HEX; old_poll=$CFG_POLL
  backend_is_running && was_running=1

  CFG_PATH_HEX=$REQ_PATH
  CFG_SHARE_HEX=$REQ_SHARE
  CFG_USER_HEX=$REQ_USER
  CFG_READONLY=$REQ_READONLY
  CFG_AUTOSTART=$REQ_AUTOSTART
  [ "$SEEN_BIND" -eq 0 ] || CFG_BIND_HEX=$REQ_BIND
  [ "$SEEN_PORT" -eq 0 ] || CFG_PORT=$REQ_PORT
  [ "$SEEN_WORKGROUP" -eq 0 ] || CFG_WORKGROUP_HEX=$REQ_WORKGROUP
  [ "$SEEN_POLL" -eq 0 ] || CFG_POLL=$REQ_POLL
  backend_decode_config || { backend_set_error E_CONFIG; return 1; }
  # Offline auto settings remain saveable. A specific address, including one
  # retained by an older client, must still be assigned at apply time.
  if [ "$CFG_BIND" != auto ]; then
    backend_select_binding || { [ -n "${BACKEND_ERROR:-}" ] || backend_set_error E_BIND; return 1; }
  fi
  backend_write_config || backend_set_error E_IO || return 1

  if [ "$was_running" -eq 1 ] && ! backend_restart; then
    CFG_PATH_HEX=$old_path; CFG_SHARE_HEX=$old_share; CFG_USER_HEX=$old_user
    CFG_READONLY=$old_readonly; CFG_AUTOSTART=$old_autostart
    CFG_BIND_HEX=$old_bind; CFG_PORT=$old_port; CFG_WORKGROUP_HEX=$old_workgroup; CFG_POLL=$old_poll
    backend_write_config >/dev/null 2>&1 || true
    backend_start >/dev/null 2>&1 || true
    backend_set_error E_START
    return 1
  fi
  backend_log INFO CONFIG_APPLIED
  return 0
}

backend_addresses() {
  local output= old_ifs record name address
  if [ "${ROOTSMB_TEST_MODE:-0}" = "1" ]; then
    if [ -n "${ROOTSMB_TEST_RECORDS:-}" ]; then
      old_ifs=$IFS; IFS=,; set -- $ROOTSMB_TEST_RECORDS; IFS=$old_ifs
      for record in "$@"; do
        case "$record" in *=*) name=${record%%=*}; address=${record#*=} ;; *) return 1 ;; esac
        case "$name" in ''|*[!A-Za-z0-9_.:-]*) return 1 ;; esac
        backend_ipv4_valid "$address" || return 1
        [ -z "$output" ] || output="$output,"
        output="$output$address"
      done
    fi
    printf '%s' "$output"
    return 0
  fi
  if command -v ip >/dev/null 2>&1; then
    output=$(ip -o -4 addr show scope global 2>/dev/null | awk '
      $2 ~ /^(wlan|wifi|eth|en|ap|swlan|rndis|usb)/ {
        split($4, a, "/"); if (a[1] != "") {
          if ($2 ~ /^(ap|swlan|rndis|usb)/) {
            if (hot != "") hot = hot ","; hot = hot a[1]
          } else {
            if (normal != "") normal = normal ","; normal = normal a[1]
          }
        }
      } END {
        if (hot != "") printf "%s", hot
        if (normal != "") { if (hot != "") printf ","; printf "%s", normal }
      }')
  fi
  printf '%s' "$output"
}

backend_load_json() {
  local password=false webdav_password=
  BACKEND_JSON=
  if ! backend_load_config; then
    [ -n "${BACKEND_ERROR:-}" ] || backend_set_error E_CONFIG
    return 1
  fi
  backend_decode_config || { backend_set_error E_CONFIG; return 1; }
  backend_password_set && password=true
  if [ -n "$CFG_PASSWORD_HEX" ]; then
    if backend_hex_decode "$CFG_PASSWORD_HEX"; then webdav_password=$BACKEND_DECODED; unset BACKEND_DECODED; fi
  elif [ -s "$WEBDAV_PASS" ]; then
    webdav_password=$(cat "$WEBDAV_PASS" 2>/dev/null)
  fi
  BACKEND_JSON=$(printf '{"sharePath":"%s","shareName":"%s","username":"%s","password":"%s","readOnly":%s,"autoStart":%s,"passwordSet":%s,"bindAddress":"%s","port":%s,"workgroup":"%s","poll":%s}' \
    "$(backend_json_escape "$CFG_PATH")" "$(backend_json_escape "$CFG_SHARE")" \
    "$(backend_json_escape "$CFG_USER")" "$(backend_json_escape "$webdav_password")" \
    "$( [ "$CFG_READONLY" = 1 ] && printf true || printf false )" \
    "$( [ "$CFG_AUTOSTART" = 1 ] && printf true || printf false )" "$password" \
    "$(backend_json_escape "$CFG_BIND")" "$CFG_PORT" "$(backend_json_escape "$CFG_WORKGROUP")" "$CFG_POLL")
}

backend_status_json() {
  local running=false pid=0 password=false addresses effective= host= address=
  BACKEND_JSON=
  if ! backend_load_config_nolock; then
    [ -n "${BACKEND_ERROR:-}" ] || backend_set_error E_CONFIG
    return 1
  fi
  if [ "${BACKEND_CONFIG_CACHED:-0}" != 1 ]; then
    backend_decode_config || { backend_set_error E_CONFIG; return 1; }
  fi
  if backend_is_running; then running=true; pid=$BACKEND_PID; fi
  backend_password_set && password=true
  if backend_resolve_share_path "$CFG_PATH"; then effective=$EFFECTIVE_PATH; fi
  addresses=$(backend_addresses) || addresses=
  printf '%s\n' "${addresses%%,*}" > "$STATE_DIR/ip" 2>/dev/null || true
  if [ "$CFG_BIND" = auto ]; then
    host=${addresses%%,*}
  else
    # Keep the saved bindAddress editable, but do not advertise a stale
    # endpoint after that address disappears from every trusted interface.
    case ",$addresses," in
      *,"$CFG_BIND",*) host=$CFG_BIND ;;
    esac
  fi
  [ -n "$host" ] && address="http://$host:$CFG_PORT/"
  BACKEND_JSON=$(printf '{"root":true,"module":true,"running":%s,"pid":%s,"sharePath":"%s","effectivePath":"%s","shareName":"%s","username":"%s","readOnly":%s,"autoStart":%s,"passwordSet":%s,"bindAddress":"%s","host":"%s","port":%s,"workgroup":"%s","address":"%s","addresses":"%s"}' \
    "$running" "$pid" "$(backend_json_escape "$CFG_PATH")" \
    "$(backend_json_escape "$effective")" "$(backend_json_escape "$CFG_SHARE")" \
    "$(backend_json_escape "$CFG_USER")" \
    "$( [ "$CFG_READONLY" = 1 ] && printf true || printf false )" \
    "$( [ "$CFG_AUTOSTART" = 1 ] && printf true || printf false )" "$password" \
    "$(backend_json_escape "$CFG_BIND")" "$(backend_json_escape "$host")" \
    "$CFG_PORT" "$(backend_json_escape "$CFG_WORKGROUP")" \
    "$(backend_json_escape "$address")" \
    "$(backend_json_escape "$addresses")")
}

backend_read_log_snippet() {
  local file=$1 max=$2 out
  [ -f "$file" ] || { printf '%s' ''; return 0; }
  out=$(tail -n 80 "$file" 2>/dev/null | tr '\000' ' ' | tail -c "$max")
  printf '%s' "$out"
}

backend_logs_json() {
  local stderr stdout backend conf procs webdavlog ipaddr bininfo logcatlines
  stderr=$(backend_read_log_snippet "$LOG_DIR/webdavd.stderr.log" 8000)
  stdout=$(backend_read_log_snippet "$LOG_DIR/webdavd.stdout.log" 4000)
  backend=$(backend_read_log_snippet "$LOG_DIR/backend.log" 8000)
  conf=$(backend_read_log_snippet "$WEBDAV_CONF" 4000)
  procs=$( { ps -A 2>/dev/null || ps -ef 2>/dev/null || ps 2>/dev/null; } | grep -E 'webdavd|smbctl' | head -n 20 | tr '\000' ' ')
  webdavlog=$(backend_read_log_snippet "$LOG_DIR/webdavd.log" 8000)
  ipaddr=$(ip -o -4 addr show scope global 2>/dev/null | head -n 20)
  bininfo=$(ls -ldZ "$WEBDAVD" "$LOG_DIR" 2>/dev/null | head -n 10)
  logcatlines=$(logcat -d -t 500 2>/dev/null | grep -iE 'webdavd|fatal signal|backtrace|tombstone|abort message' | tail -n 60)
  BACKEND_JSON=$(printf '{"stderr":"%s","stdout":"%s","backend":"%s","webdavConf":"%s","procs":"%s","webdavLog":"%s","ipAddr":"%s","binInfo":"%s","logcat":"%s"}' \
    "$(backend_json_escape "$stderr")" "$(backend_json_escape "$stdout")" \
    "$(backend_json_escape "$backend")" "$(backend_json_escape "$conf")" \
    "$(backend_json_escape "$procs")" "$(backend_json_escape "$webdavlog")" \
    "$(backend_json_escape "$ipaddr")" "$(backend_json_escape "$bininfo")" \
    "$(backend_json_escape "$logcatlines")")
}

backend_parse_request() {
  local line key value ended=0 lines=0 total=0
  REQ_OP=
  REQ_PATH=; REQ_SHARE=; REQ_USER=; REQ_PASSWORD=
  REQ_READONLY=; REQ_AUTOSTART=
  REQ_BIND=; REQ_PORT=; REQ_WORKGROUP=; REQ_POLL=
  SEEN_PATH=0; SEEN_SHARE=0; SEEN_USER=0; SEEN_PASSWORD=0
  SEEN_READONLY=0; SEEN_AUTOSTART=0
  SEEN_BIND=0; SEEN_PORT=0; SEEN_WORKGROUP=0; SEEN_POLL=0

  IFS= read -r line || backend_set_error E_BAD_REQUEST || return 1
  [ "$line" = ROOTSMB/1 ] || backend_set_error E_BAD_VERSION || return 1
  total=${#line}
  IFS= read -r line || backend_set_error E_BAD_REQUEST || return 1
  case "$line" in OP=*) REQ_OP=${line#OP=} ;; *) backend_set_error E_BAD_REQUEST; return 1 ;; esac
  case "$REQ_OP" in
    status|load|apply|password|start|stop|restart|force-restart|logs) ;;
    install-check|recover)
      [ "${ROOTSMB_INSTALL_MODE:-0}" = 1 ] || { backend_set_error E_BAD_OPERATION; return 1; }
      ;;
    *) backend_set_error E_BAD_OPERATION; return 1 ;;
  esac
  total=$((total + ${#line}))

  while IFS= read -r line; do
    lines=$((lines + 1))
    [ "$lines" -le 16 ] || backend_set_error E_TOO_LARGE || return 1
    total=$((total + ${#line}))
    [ "$total" -le 16384 ] && [ "${#line}" -le 8192 ] || backend_set_error E_TOO_LARGE || return 1
    if [ "$line" = END ]; then ended=1; break; fi
    case "$line" in *=*) key=${line%%=*}; value=${line#*=} ;; *) backend_set_error E_BAD_FIELD; return 1 ;; esac
    case "$key" in
      PATH) [ "$SEEN_PATH" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_PATH=$value; SEEN_PATH=1 ;;
      SHARE) [ "$SEEN_SHARE" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_SHARE=$value; SEEN_SHARE=1 ;;
      USER) [ "$SEEN_USER" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_USER=$value; SEEN_USER=1 ;;
      PASSWORD) [ "$SEEN_PASSWORD" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_PASSWORD=$value; SEEN_PASSWORD=1 ;;
      READONLY) [ "$SEEN_READONLY" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_READONLY=$value; SEEN_READONLY=1 ;;
      AUTOSTART) [ "$SEEN_AUTOSTART" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_AUTOSTART=$value; SEEN_AUTOSTART=1 ;;
      BIND) [ "$SEEN_BIND" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_BIND=$value; SEEN_BIND=1 ;;
      PORT) [ "$SEEN_PORT" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_PORT=$value; SEEN_PORT=1 ;;
      WORKGROUP) [ "$SEEN_WORKGROUP" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_WORKGROUP=$value; SEEN_WORKGROUP=1 ;;
      POLL) [ "$SEEN_POLL" -eq 0 ] || backend_set_error E_BAD_FIELD || return 1; REQ_POLL=$value; SEEN_POLL=1 ;;
      *) backend_set_error E_BAD_FIELD; return 1 ;;
    esac
  done
  [ "$ended" -eq 1 ] || backend_set_error E_BAD_REQUEST || return 1
  line=
  if IFS= read -r line || [ -n "$line" ]; then backend_set_error E_BAD_REQUEST; return 1; fi

  case "$REQ_OP" in
    apply)
      [ "$SEEN_PATH" -eq 1 ] && [ "$SEEN_SHARE" -eq 1 ] && [ "$SEEN_USER" -eq 1 ] && \
        [ "$SEEN_READONLY" -eq 1 ] && [ "$SEEN_AUTOSTART" -eq 1 ] && [ "$SEEN_PASSWORD" -eq 0 ] \
        || backend_set_error E_BAD_FIELD || return 1
      ;;
    password)
      [ "$SEEN_PASSWORD" -eq 1 ] && [ "$SEEN_PATH" -eq 0 ] && [ "$SEEN_SHARE" -eq 0 ] && \
        [ "$SEEN_USER" -eq 0 ] && [ "$SEEN_READONLY" -eq 0 ] && [ "$SEEN_AUTOSTART" -eq 0 ] && \
        [ "$SEEN_BIND" -eq 0 ] && [ "$SEEN_PORT" -eq 0 ] && [ "$SEEN_WORKGROUP" -eq 0 ] && [ "$SEEN_POLL" -eq 0 ] \
        || backend_set_error E_BAD_FIELD || return 1
      ;;
    *)
      [ "$SEEN_PATH" -eq 0 ] && [ "$SEEN_SHARE" -eq 0 ] && [ "$SEEN_USER" -eq 0 ] && \
        [ "$SEEN_PASSWORD" -eq 0 ] && [ "$SEEN_READONLY" -eq 0 ] && [ "$SEEN_AUTOSTART" -eq 0 ] && \
        [ "$SEEN_BIND" -eq 0 ] && [ "$SEEN_PORT" -eq 0 ] && [ "$SEEN_WORKGROUP" -eq 0 ] && [ "$SEEN_POLL" -eq 0 ] \
        || backend_set_error E_BAD_FIELD || return 1
      ;;
  esac
}

backend_rpc() {
  local code
  BACKEND_ERROR=
  backend_parse_request || { backend_json_error "${BACKEND_ERROR:-E_BAD_REQUEST}"; return 1; }
  case "$REQ_OP" in
    logs)
      backend_logs_json
      backend_json_ok "$BACKEND_JSON"
      ;;
    status)
      backend_status_json || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
      backend_json_ok "$BACKEND_JSON"
      ;;
    load)
      backend_load_json || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
      backend_json_ok "$BACKEND_JSON"
      ;;
    install-check)
      backend_load_config || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
      backend_json_ok '{"ready":true}'
      ;;
    recover)
      backend_lock_acquire || { backend_json_error "${BACKEND_ERROR:-E_BUSY}"; return 1; }
      if backend_recover_config; then code=OK; else code=${BACKEND_ERROR:-E_INTERNAL}; fi
      backend_lock_release
      if [ "$code" = OK ]; then
        backend_json_ok "{\"quarantined\":$BACKEND_RECOVERY_QUARANTINED,\"backupName\":\"$(backend_json_escape "$BACKEND_RECOVERY_BACKUP_NAME")\"}"
      else
        backend_json_error "$code"
        return 1
      fi
      ;;
    force-restart)
      if backend_force_restart; then code=OK; else code=${BACKEND_ERROR:-E_INTERNAL}; fi
      if [ "$code" = OK ]; then
        backend_status_json || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
        backend_json_ok "$BACKEND_JSON"
      else backend_json_error "$code"; return 1; fi
      ;;
    apply)
      backend_lock_acquire || { backend_json_error "${BACKEND_ERROR:-E_BUSY}"; return 1; }
      if backend_apply_config; then code=OK; else code=${BACKEND_ERROR:-E_INTERNAL}; fi
      backend_lock_release
      if [ "$code" = OK ]; then
        backend_load_json || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
        backend_json_ok "$BACKEND_JSON"
      else backend_json_error "$code"; return 1; fi
      ;;
    password)
      backend_lock_acquire || { unset REQ_PASSWORD; backend_json_error "${BACKEND_ERROR:-E_BUSY}"; return 1; }
      if backend_install_password "$REQ_PASSWORD"; then code=OK; else code=${BACKEND_ERROR:-E_INTERNAL}; fi
      unset REQ_PASSWORD
      backend_lock_release
      if [ "$code" = OK ]; then backend_json_ok '{"passwordSet":true}'; else backend_json_error "$code"; return 1; fi
      ;;
    start)
      backend_lock_acquire || { backend_json_error "${BACKEND_ERROR:-E_BUSY}"; return 1; }
      if backend_start; then code=OK; else code=${BACKEND_ERROR:-E_START}; fi
      backend_lock_release
      if [ "$code" = OK ]; then
        backend_status_json || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
        backend_json_ok "$BACKEND_JSON"
      else backend_json_error "$code"; return 1; fi
      ;;
    stop)
      backend_lock_acquire || { backend_json_error "${BACKEND_ERROR:-E_BUSY}"; return 1; }
      if backend_stop; then code=OK; else code=${BACKEND_ERROR:-E_STOP}; fi
      backend_lock_release
      if [ "$code" = OK ]; then
        backend_status_json || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
        backend_json_ok "$BACKEND_JSON"
      else backend_json_error "$code"; return 1; fi
      ;;
    restart)
      backend_lock_acquire || { backend_json_error "${BACKEND_ERROR:-E_BUSY}"; return 1; }
      if backend_restart; then code=OK; else code=${BACKEND_ERROR:-E_START}; fi
      backend_lock_release
      if [ "$code" = OK ]; then
        backend_status_json || { backend_json_error "${BACKEND_ERROR:-E_CONFIG}"; return 1; }
        backend_json_ok "$BACKEND_JSON"
      else backend_json_error "$code"; return 1; fi
      ;;
  esac
}
