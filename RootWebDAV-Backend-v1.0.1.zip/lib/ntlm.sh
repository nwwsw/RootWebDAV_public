#!/system/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Small, dependency-free NT hash implementation for Android's mksh.
# The caller passes an uppercase/lowercase hexadecimal UTF-8 byte string.
# No password material is placed in argv, a file, stdout, or a log.

NTLM_MASK32=4294967295

ntlm_hex_is_valid() {
  local value="$1"
  case "$value" in
    ''|*[!0-9A-Fa-f]*) return 1 ;;
  esac
  [ $(( ${#value} % 2 )) -eq 0 ]
}

ntlm_utf8_to_utf16le() {
  local input="$1" length pos=0
  local b1 b2 b3 b4 cp high low tail
  NTLM_UTF16_HEX=
  ntlm_hex_is_valid "$input" || return 1
  length=${#input}

  while [ "$pos" -lt "$length" ]; do
    b1=$((0x${input:$pos:2}))
    if [ "$b1" -le 127 ]; then
      # U+0000 cannot be represented safely in shell variables and is not a
      # useful SMB password character.
      [ "$b1" -ne 0 ] || return 1
      NTLM_UTF16_HEX="${NTLM_UTF16_HEX}${input:$pos:2}00"
      pos=$((pos + 2))
      continue
    fi

    if [ "$b1" -ge 194 ] && [ "$b1" -le 223 ]; then
      [ $((pos + 4)) -le "$length" ] || return 1
      b2=$((0x${input:$((pos + 2)):2}))
      [ "$b2" -ge 128 ] && [ "$b2" -le 191 ] || return 1
      cp=$(( ((b1 & 31) << 6) | (b2 & 63) ))
      tail="$(printf '%02X%02X' $((cp & 255)) $(((cp >> 8) & 255)))"
      NTLM_UTF16_HEX="${NTLM_UTF16_HEX}${tail}"
      pos=$((pos + 4))
      continue
    fi

    if [ "$b1" -ge 224 ] && [ "$b1" -le 239 ]; then
      [ $((pos + 6)) -le "$length" ] || return 1
      b2=$((0x${input:$((pos + 2)):2}))
      b3=$((0x${input:$((pos + 4)):2}))
      [ "$b2" -ge 128 ] && [ "$b2" -le 191 ] || return 1
      [ "$b3" -ge 128 ] && [ "$b3" -le 191 ] || return 1
      [ "$b1" -ne 224 ] || [ "$b2" -ge 160 ] || return 1
      [ "$b1" -ne 237 ] || [ "$b2" -le 159 ] || return 1
      cp=$(( ((b1 & 15) << 12) | ((b2 & 63) << 6) | (b3 & 63) ))
      [ "$cp" -lt 55296 ] || [ "$cp" -gt 57343 ] || return 1
      tail="$(printf '%02X%02X' $((cp & 255)) $(((cp >> 8) & 255)))"
      NTLM_UTF16_HEX="${NTLM_UTF16_HEX}${tail}"
      pos=$((pos + 6))
      continue
    fi

    if [ "$b1" -ge 240 ] && [ "$b1" -le 244 ]; then
      [ $((pos + 8)) -le "$length" ] || return 1
      b2=$((0x${input:$((pos + 2)):2}))
      b3=$((0x${input:$((pos + 4)):2}))
      b4=$((0x${input:$((pos + 6)):2}))
      [ "$b2" -ge 128 ] && [ "$b2" -le 191 ] || return 1
      [ "$b3" -ge 128 ] && [ "$b3" -le 191 ] || return 1
      [ "$b4" -ge 128 ] && [ "$b4" -le 191 ] || return 1
      [ "$b1" -ne 240 ] || [ "$b2" -ge 144 ] || return 1
      [ "$b1" -ne 244 ] || [ "$b2" -le 143 ] || return 1
      cp=$(( ((b1 & 7) << 18) | ((b2 & 63) << 12) | ((b3 & 63) << 6) | (b4 & 63) ))
      [ "$cp" -le 1114111 ] || return 1
      cp=$((cp - 65536))
      high=$((55296 | ((cp >> 10) & 1023)))
      low=$((56320 | (cp & 1023)))
      tail="$(printf '%02X%02X%02X%02X' \
        $((high & 255)) $(((high >> 8) & 255)) \
        $((low & 255)) $(((low >> 8) & 255)))"
      NTLM_UTF16_HEX="${NTLM_UTF16_HEX}${tail}"
      pos=$((pos + 8))
      continue
    fi

    return 1
  done
  return 0
}

ntlm_rol32() {
  local value=$(( $1 & NTLM_MASK32 )) shift="$2"
  NTLM_ROL=$(( ((value << shift) | (value >> (32 - shift))) & NTLM_MASK32 ))
}

ntlm_ff() {
  local a="$1" b="$2" c="$3" d="$4" x="$5" shift="$6" f
  f=$(( (b & c) | ((~b) & d) ))
  ntlm_rol32 $(( (a + f + x) & NTLM_MASK32 )) "$shift"
  NTLM_STEP=$NTLM_ROL
}

ntlm_gg() {
  local a="$1" b="$2" c="$3" d="$4" x="$5" shift="$6" g
  g=$(( (b & c) | (b & d) | (c & d) ))
  ntlm_rol32 $(( (a + g + x + 1518500249) & NTLM_MASK32 )) "$shift"
  NTLM_STEP=$NTLM_ROL
}

ntlm_hh() {
  local a="$1" b="$2" c="$3" d="$4" x="$5" shift="$6" h
  h=$(( b ^ c ^ d ))
  ntlm_rol32 $(( (a + h + x + 1859775393) & NTLM_MASK32 )) "$shift"
  NTLM_STEP=$NTLM_ROL
}

ntlm_word_le() {
  local block="$1" offset="$2" b0 b1 b2 b3
  b0=$((0x${block:$offset:2}))
  b1=$((0x${block:$((offset + 2)):2}))
  b2=$((0x${block:$((offset + 4)):2}))
  b3=$((0x${block:$((offset + 6)):2}))
  NTLM_WORD=$(( (b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)) & NTLM_MASK32 ))
}

ntlm_le32_hex() {
  local value=$(( $1 & NTLM_MASK32 ))
  printf '%02X%02X%02X%02X' \
    $((value & 255)) $(((value >> 8) & 255)) \
    $(((value >> 16) & 255)) $(((value >> 24) & 255))
}

ntlm_hash_hex() {
  local utf8_hex="$1" message bytes bit_length padding block offset
  local a=1732584193 b=4023233417 c=2562383102 d=271733878
  local aa bb cc dd
  local x0 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12 x13 x14 x15

  ntlm_utf8_to_utf16le "$utf8_hex" || return 1
  message=$NTLM_UTF16_HEX
  bytes=$(( ${#message} / 2 ))
  bit_length=$((bytes * 8))
  message="${message}80"
  while [ $(( (${#message} / 2) % 64 )) -ne 56 ]; do
    message="${message}00"
  done
  padding="$(ntlm_le32_hex "$bit_length")00000000"
  message="${message}${padding}"

  offset=0
  while [ "$offset" -lt "${#message}" ]; do
    block=${message:$offset:128}
    ntlm_word_le "$block" 0; x0=$NTLM_WORD
    ntlm_word_le "$block" 8; x1=$NTLM_WORD
    ntlm_word_le "$block" 16; x2=$NTLM_WORD
    ntlm_word_le "$block" 24; x3=$NTLM_WORD
    ntlm_word_le "$block" 32; x4=$NTLM_WORD
    ntlm_word_le "$block" 40; x5=$NTLM_WORD
    ntlm_word_le "$block" 48; x6=$NTLM_WORD
    ntlm_word_le "$block" 56; x7=$NTLM_WORD
    ntlm_word_le "$block" 64; x8=$NTLM_WORD
    ntlm_word_le "$block" 72; x9=$NTLM_WORD
    ntlm_word_le "$block" 80; x10=$NTLM_WORD
    ntlm_word_le "$block" 88; x11=$NTLM_WORD
    ntlm_word_le "$block" 96; x12=$NTLM_WORD
    ntlm_word_le "$block" 104; x13=$NTLM_WORD
    ntlm_word_le "$block" 112; x14=$NTLM_WORD
    ntlm_word_le "$block" 120; x15=$NTLM_WORD

    aa=$a; bb=$b; cc=$c; dd=$d

    ntlm_ff "$a" "$b" "$c" "$d" "$x0" 3; a=$NTLM_STEP
    ntlm_ff "$d" "$a" "$b" "$c" "$x1" 7; d=$NTLM_STEP
    ntlm_ff "$c" "$d" "$a" "$b" "$x2" 11; c=$NTLM_STEP
    ntlm_ff "$b" "$c" "$d" "$a" "$x3" 19; b=$NTLM_STEP
    ntlm_ff "$a" "$b" "$c" "$d" "$x4" 3; a=$NTLM_STEP
    ntlm_ff "$d" "$a" "$b" "$c" "$x5" 7; d=$NTLM_STEP
    ntlm_ff "$c" "$d" "$a" "$b" "$x6" 11; c=$NTLM_STEP
    ntlm_ff "$b" "$c" "$d" "$a" "$x7" 19; b=$NTLM_STEP
    ntlm_ff "$a" "$b" "$c" "$d" "$x8" 3; a=$NTLM_STEP
    ntlm_ff "$d" "$a" "$b" "$c" "$x9" 7; d=$NTLM_STEP
    ntlm_ff "$c" "$d" "$a" "$b" "$x10" 11; c=$NTLM_STEP
    ntlm_ff "$b" "$c" "$d" "$a" "$x11" 19; b=$NTLM_STEP
    ntlm_ff "$a" "$b" "$c" "$d" "$x12" 3; a=$NTLM_STEP
    ntlm_ff "$d" "$a" "$b" "$c" "$x13" 7; d=$NTLM_STEP
    ntlm_ff "$c" "$d" "$a" "$b" "$x14" 11; c=$NTLM_STEP
    ntlm_ff "$b" "$c" "$d" "$a" "$x15" 19; b=$NTLM_STEP

    ntlm_gg "$a" "$b" "$c" "$d" "$x0" 3; a=$NTLM_STEP
    ntlm_gg "$d" "$a" "$b" "$c" "$x4" 5; d=$NTLM_STEP
    ntlm_gg "$c" "$d" "$a" "$b" "$x8" 9; c=$NTLM_STEP
    ntlm_gg "$b" "$c" "$d" "$a" "$x12" 13; b=$NTLM_STEP
    ntlm_gg "$a" "$b" "$c" "$d" "$x1" 3; a=$NTLM_STEP
    ntlm_gg "$d" "$a" "$b" "$c" "$x5" 5; d=$NTLM_STEP
    ntlm_gg "$c" "$d" "$a" "$b" "$x9" 9; c=$NTLM_STEP
    ntlm_gg "$b" "$c" "$d" "$a" "$x13" 13; b=$NTLM_STEP
    ntlm_gg "$a" "$b" "$c" "$d" "$x2" 3; a=$NTLM_STEP
    ntlm_gg "$d" "$a" "$b" "$c" "$x6" 5; d=$NTLM_STEP
    ntlm_gg "$c" "$d" "$a" "$b" "$x10" 9; c=$NTLM_STEP
    ntlm_gg "$b" "$c" "$d" "$a" "$x14" 13; b=$NTLM_STEP
    ntlm_gg "$a" "$b" "$c" "$d" "$x3" 3; a=$NTLM_STEP
    ntlm_gg "$d" "$a" "$b" "$c" "$x7" 5; d=$NTLM_STEP
    ntlm_gg "$c" "$d" "$a" "$b" "$x11" 9; c=$NTLM_STEP
    ntlm_gg "$b" "$c" "$d" "$a" "$x15" 13; b=$NTLM_STEP

    ntlm_hh "$a" "$b" "$c" "$d" "$x0" 3; a=$NTLM_STEP
    ntlm_hh "$d" "$a" "$b" "$c" "$x8" 9; d=$NTLM_STEP
    ntlm_hh "$c" "$d" "$a" "$b" "$x4" 11; c=$NTLM_STEP
    ntlm_hh "$b" "$c" "$d" "$a" "$x12" 15; b=$NTLM_STEP
    ntlm_hh "$a" "$b" "$c" "$d" "$x2" 3; a=$NTLM_STEP
    ntlm_hh "$d" "$a" "$b" "$c" "$x10" 9; d=$NTLM_STEP
    ntlm_hh "$c" "$d" "$a" "$b" "$x6" 11; c=$NTLM_STEP
    ntlm_hh "$b" "$c" "$d" "$a" "$x14" 15; b=$NTLM_STEP
    ntlm_hh "$a" "$b" "$c" "$d" "$x1" 3; a=$NTLM_STEP
    ntlm_hh "$d" "$a" "$b" "$c" "$x9" 9; d=$NTLM_STEP
    ntlm_hh "$c" "$d" "$a" "$b" "$x5" 11; c=$NTLM_STEP
    ntlm_hh "$b" "$c" "$d" "$a" "$x13" 15; b=$NTLM_STEP
    ntlm_hh "$a" "$b" "$c" "$d" "$x3" 3; a=$NTLM_STEP
    ntlm_hh "$d" "$a" "$b" "$c" "$x11" 9; d=$NTLM_STEP
    ntlm_hh "$c" "$d" "$a" "$b" "$x7" 11; c=$NTLM_STEP
    ntlm_hh "$b" "$c" "$d" "$a" "$x15" 15; b=$NTLM_STEP

    a=$(( (a + aa) & NTLM_MASK32 ))
    b=$(( (b + bb) & NTLM_MASK32 ))
    c=$(( (c + cc) & NTLM_MASK32 ))
    d=$(( (d + dd) & NTLM_MASK32 ))
    offset=$((offset + 128))
  done

  NTLM_HASH="$(ntlm_le32_hex "$a")$(ntlm_le32_hex "$b")$(ntlm_le32_hex "$c")$(ntlm_le32_hex "$d")"
  unset NTLM_UTF16_HEX message block utf8_hex
  return 0
}
