#!/system/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later

MODDIR=${0%/*}
CONTROL=$MODDIR/bin/smbctl
DATA_DIR=/data/adb/rootsmb

[ -r "$CONTROL" ] && printf 'ROOTSMB/1\nOP=stop\nEND\n' | sh "$CONTROL" rpc >/dev/null 2>&1 || true

# Credentials are removed on uninstall. The non-secret configuration is kept so
# a reinstall can recover the user's share choices.
rm -f "$DATA_DIR/runtime/private/smbpasswd" \
  "$DATA_DIR/runtime/private/username.map" \
  "$DATA_DIR/runtime/smb.conf" \
  "$DATA_DIR/runtime/run/webdavd.pid" 2>/dev/null
