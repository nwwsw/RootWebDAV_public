#!/system/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later

SKIPUNZIP=1
ROOTSMB_EXPECTED_WEBDAVD_SHA256=22A5060B0C928A50BA9CD96F573609EA59FD690F1B7C5A235226789CAA391266
ROOTSMB_EXPECTED_CRYPT_SHA256=5B3834E720ED9CB611370E27594A98F58EBF1953846A0F9A2F2311313BE5C27F
ROOTSMB_EXPECTED_CTLD_SHA256=8F65F2AD6C3F9C971983C17EBC7648757359F7DD168389858AB621A2A96D1820
if [ "${ROOTSMB_TEST_MODE:-0}" = 1 ]; then
  ROOTSMB_DATA_DIR=${ROOTSMB_TEST_DATA_DIR:?ROOTSMB_TEST_DATA_DIR is required}
else
  ROOTSMB_DATA_DIR=/data/adb/rootsmb
fi

ui_print "- Installing Root WebDAV Companion Backend"
ui_print "- Architecture: $ARCH; Android API: $API"

[ "$ARCH" = arm64 ] || abort "! This package contains only the arm64-v8a webdavd binary"

ui_print "- Extracting module payload"
unzip -o "$ZIPFILE" \
  'module.prop' 'service.sh' 'action.sh' 'uninstall.sh' 'README.md' \
  'LICENSE' 'THIRD_PARTY_NOTICES.md' 'checksums.sha256' \
  'sepolicy.rule' 'bin/*' 'lib/*' \
  -d "$MODPATH" >&2 || abort "! Failed to extract module payload"

[ -f "$MODPATH/bin/webdavd" ] || abort "! Missing bin/webdavd"
[ -f "$MODPATH/bin/rootsmb-crypt" ] || abort "! Missing bin/rootsmb-crypt"
[ -f "$MODPATH/bin/rootsmb-ctld" ] || abort "! Missing bin/rootsmb-ctld"
[ -f "$MODPATH/bin/smbctl" ] || abort "! Missing bin/smbctl"
[ -f "$MODPATH/checksums.sha256" ] || abort "! Missing checksums.sha256"

rootsmb_hash_file() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" 2>/dev/null | awk '{print toupper($1)}'
  elif command -v toybox >/dev/null 2>&1; then
    toybox sha256sum "$1" 2>/dev/null | awk '{print toupper($1)}'
  elif command -v busybox >/dev/null 2>&1; then
    busybox sha256sum "$1" 2>/dev/null | awk '{print toupper($1)}'
  else
    return 1
  fi
}

ROOTSMB_MANIFEST_HASH=$(awk '$2 == "bin/webdavd" { print toupper($1) }' "$MODPATH/checksums.sha256" 2>/dev/null)
[ "$ROOTSMB_MANIFEST_HASH" = "$ROOTSMB_EXPECTED_WEBDAVD_SHA256" ] || abort "! Invalid webdavd checksum manifest"
ROOTSMB_ACTUAL_HASH=$(rootsmb_hash_file "$MODPATH/bin/webdavd") || abort "! No SHA-256 implementation available"
[ "$ROOTSMB_ACTUAL_HASH" = "$ROOTSMB_EXPECTED_WEBDAVD_SHA256" ] || abort "! bin/webdavd failed SHA-256 verification"
ui_print "- Verified webdavd SHA-256: $ROOTSMB_ACTUAL_HASH"
ROOTSMB_CRYPT_HASH=$(rootsmb_hash_file "$MODPATH/bin/rootsmb-crypt") || abort "! No SHA-256 implementation available"
[ "$ROOTSMB_CRYPT_HASH" = "$ROOTSMB_EXPECTED_CRYPT_SHA256" ] || abort "! bin/rootsmb-crypt failed SHA-256 verification"
ui_print "- Verified rootsmb-crypt SHA-256: $ROOTSMB_CRYPT_HASH"
ROOTSMB_CTLD_HASH=$(rootsmb_hash_file "$MODPATH/bin/rootsmb-ctld") || abort "! No SHA-256 implementation available"
[ "$ROOTSMB_CTLD_HASH" = "$ROOTSMB_EXPECTED_CTLD_SHA256" ] || abort "! bin/rootsmb-ctld failed SHA-256 verification"
ui_print "- Verified rootsmb-ctld SHA-256: $ROOTSMB_CTLD_HASH"

touch "$MODPATH/skip_mount"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/bin/webdavd" 0 0 0755
set_perm "$MODPATH/bin/rootsmb-crypt" 0 0 0755
set_perm "$MODPATH/bin/rootsmb-ctld" 0 0 0755
set_perm "$MODPATH/bin/smbctl" 0 0 0755
set_perm "$MODPATH/customize.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

mkdir -p "$ROOTSMB_DATA_DIR/runtime/log" "$ROOTSMB_DATA_DIR/runtime/private" "$ROOTSMB_DATA_DIR/runtime/run" \
  "$ROOTSMB_DATA_DIR/runtime/state" "$ROOTSMB_DATA_DIR/runtime/cache" \
  || abort "! Failed to create secure backend data directories"
chmod 0700 "$ROOTSMB_DATA_DIR" "$ROOTSMB_DATA_DIR/runtime" "$ROOTSMB_DATA_DIR/runtime/log" \
  "$ROOTSMB_DATA_DIR/runtime/private" "$ROOTSMB_DATA_DIR/runtime/run" \
  "$ROOTSMB_DATA_DIR/runtime/state" "$ROOTSMB_DATA_DIR/runtime/cache" 2>/dev/null \
  || abort "! Failed to set secure backend directory modes"
chown 0:0 "$ROOTSMB_DATA_DIR" "$ROOTSMB_DATA_DIR/runtime" "$ROOTSMB_DATA_DIR/runtime/log" \
  "$ROOTSMB_DATA_DIR/runtime/private" "$ROOTSMB_DATA_DIR/runtime/run" \
  "$ROOTSMB_DATA_DIR/runtime/state" "$ROOTSMB_DATA_DIR/runtime/cache" 2>/dev/null \
  || abort "! Failed to set secure backend directory ownership"

# Initialize or strictly validate the data-only configuration. Installer-only
# operations return small fixed JSON objects; no configuration value is printed
# or sourced by this shell.
ROOTSMB_CONFIG_FILE=$ROOTSMB_DATA_DIR/config.conf
if [ -e "$ROOTSMB_CONFIG_FILE" ] || [ -L "$ROOTSMB_CONFIG_FILE" ]; then
  [ -f "$ROOTSMB_CONFIG_FILE" ] && [ ! -L "$ROOTSMB_CONFIG_FILE" ] \
    || abort "! Refusing non-regular backend configuration path: $ROOTSMB_CONFIG_FILE"
fi

rootsmb_rpc() {
  ROOTSMB_RPC_OP=$1
  if ROOTSMB_RPC_REPLY=$(printf 'ROOTSMB/1\nOP=%s\nEND\n' "$ROOTSMB_RPC_OP" \
      | (ROOTSMB_INSTALL_MODE=1; export ROOTSMB_INSTALL_MODE
         sh "$MODPATH/bin/smbctl" rpc 2>/dev/null)); then
    ROOTSMB_RPC_RC=0
  else
    ROOTSMB_RPC_RC=$?
  fi
  ROOTSMB_SAFE_REPLY=$(printf '%s\n' "$ROOTSMB_RPC_REPLY" \
    | sed -n '/^{"ok":false,"code":"E_[A-Z0-9_]*","message":"[^"]*"}$/p')
  ROOTSMB_RPC_CODE=
  if [ -n "$ROOTSMB_SAFE_REPLY" ] && \
      [ "$ROOTSMB_SAFE_REPLY" = "$ROOTSMB_RPC_REPLY" ] && \
      [ "${#ROOTSMB_SAFE_REPLY}" -le 1024 ]; then
    ROOTSMB_CANDIDATE_CODE=$(printf '%s\n' "$ROOTSMB_SAFE_REPLY" \
      | sed -n 's/^.*"code":"\(E_[A-Z0-9_]*\)".*$/\1/p')
    case "$ROOTSMB_CANDIDATE_CODE" in
      E_BAD_REQUEST|E_BAD_VERSION|E_BAD_OPERATION|E_BAD_FIELD|E_TOO_LARGE|E_NOT_ROOT|\
      E_BUSY|E_CONFIG|E_CONFIG_PATH|E_PATH|E_BIND|E_PORT|E_PASSWORD|\
      E_PASSWORD_REQUIRED|E_BINARY|E_FOREIGN_SERVER|E_START|E_STOP|E_IO|E_INTERNAL)
        ROOTSMB_RPC_CODE=$ROOTSMB_CANDIDATE_CODE
        ;;
    esac
  fi
}

rootsmb_print_rpc_error() {
  if [ -n "$ROOTSMB_RPC_CODE" ]; then
    case "$ROOTSMB_RPC_CODE" in
      E_CONFIG) ROOTSMB_LOCAL_ERROR='configuration is invalid' ;;
      E_CONFIG_PATH) ROOTSMB_LOCAL_ERROR='configuration path is not a regular file' ;;
      E_BUSY) ROOTSMB_LOCAL_ERROR='backend lock is busy' ;;
      E_IO) ROOTSMB_LOCAL_ERROR='secure storage operation failed' ;;
      E_NOT_ROOT) ROOTSMB_LOCAL_ERROR='root permission is required' ;;
      E_BINARY) ROOTSMB_LOCAL_ERROR='backend component is missing' ;;
      *) ROOTSMB_LOCAL_ERROR='backend rejected the installer request' ;;
    esac
    ui_print "! Backend initialization error [$ROOTSMB_RPC_CODE]: $ROOTSMB_LOCAL_ERROR"
  else
    ui_print "! Backend initialization failed with exit code $ROOTSMB_RPC_RC (no valid error JSON)"
  fi
}

rootsmb_rpc install-check
if [ "$ROOTSMB_RPC_RC" -eq 0 ]; then
  [ "${#ROOTSMB_RPC_REPLY}" -le 1024 ] && \
    [ "$ROOTSMB_RPC_REPLY" = '{"ok":true,"code":"OK","data":{"ready":true}}' ] \
    || abort "! Backend initialization returned malformed success JSON"
else
  rootsmb_print_rpc_error
  if [ "$ROOTSMB_RPC_CODE" = E_CONFIG ]; then
    rootsmb_rpc recover
    if [ "$ROOTSMB_RPC_RC" -ne 0 ]; then
      rootsmb_print_rpc_error
      abort "! Failed to recover backend configuration"
    fi
    ROOTSMB_NO_BACKUP='{"ok":true,"code":"OK","data":{"quarantined":false,"backupName":""}}'
    if [ "$ROOTSMB_RPC_REPLY" = "$ROOTSMB_NO_BACKUP" ]; then
      ui_print "- Configuration became valid or absent before recovery; no backup was needed"
    else
      ROOTSMB_BACKUP_NAME=$(printf '%s\n' "$ROOTSMB_RPC_REPLY" | sed -n \
        's/^{"ok":true,"code":"OK","data":{"quarantined":true,"backupName":"\(config\.conf\.rejected-v051-[0-9][0-9]*\)"}}$/\1/p')
      ROOTSMB_EXPECTED_BACKUP="{\"ok\":true,\"code\":\"OK\",\"data\":{\"quarantined\":true,\"backupName\":\"$ROOTSMB_BACKUP_NAME\"}}"
      [ -n "$ROOTSMB_BACKUP_NAME" ] && [ "${#ROOTSMB_RPC_REPLY}" -le 1024 ] && \
        [ "$ROOTSMB_RPC_REPLY" = "$ROOTSMB_EXPECTED_BACKUP" ] \
        || abort "! Backend recovery returned malformed success JSON"
      ui_print "! Preserved rejected configuration: $ROOTSMB_DATA_DIR/$ROOTSMB_BACKUP_NAME"
      ui_print "- Initialized defaults after isolating rejected configuration"
    fi
  else
    abort "! Failed to initialize secure backend configuration"
  fi
fi


ui_print "- Installed. Reboot, then grant the controller APK root access."
