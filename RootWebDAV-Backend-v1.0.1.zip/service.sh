#!/system/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later

MODDIR=${0%/*}
CTLD=$MODDIR/bin/rootsmb-ctld
CTLD_PID=/data/adb/rootsmb/runtime/run/ctld.pid

start_ctld() {
  [ -x "$CTLD" ] || return 0
  if [ -s "$CTLD_PID" ] && kill -0 "$(cat "$CTLD_PID" 2>/dev/null)" 2>/dev/null; then
    return 0
  fi
  mkdir -p "$(dirname "$CTLD_PID")" 2>/dev/null || true
  if command -v setsid >/dev/null 2>&1; then
    setsid "$CTLD" >/dev/null 2>&1 < /dev/null &
  else
    "$CTLD" >/dev/null 2>&1 < /dev/null &
  fi
  return 0
}

case "$1" in
  start|stop|restart)
    . "$MODDIR/lib/backend.sh" || exit 1
    start_ctld
    backend_load_config || { backend_log ERROR MANUAL_CONFIG_INVALID; exit 1; }
    backend_lock_acquire || exit 1
    case "$1" in
      stop) backend_stop; rc=$? ;;
      start) backend_start; rc=$? ;;
      restart) backend_stop >/dev/null 2>&1 || true; backend_start; rc=$? ;;
    esac
    backend_lock_release
    exit "$rc"
    ;;
esac

# Boot autostart. Magisk/KernelSU/APatch execute this script in the late_start
# boot stage. The server does not need a hotspot IP (it binds 0.0.0.0), but the
# configured share directory is usually /storage/emulated/0/... and is only
# mounted after the user unlocks the device once. We therefore write a marker
# file first (to prove this script ran), wait for boot completion, and retry
# until the share path becomes available instead of giving up on one failure.

BOOT_MARKER=${ROOTSMB_TEST_BOOT_MARKER:-/data/adb/rootsmb/runtime/state/boot.marker}
mkdir -p "$(dirname "$BOOT_MARKER")" 2>/dev/null || true
{
  printf 'boot: service.sh executed pid=%s at %s\n' \
    "$$" "$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null)"
  printf 'boot: module=%s boot_completed=%s\n' \
    "$MODDIR" "$(getprop sys.boot_completed 2>/dev/null)"
} >> "$BOOT_MARKER" 2>/dev/null || true

[ -r "$MODDIR/lib/backend.sh" ] || {
  printf 'boot: lib/backend.sh missing\n' >> "$BOOT_MARKER" 2>/dev/null || true
  exit 0
}
. "$MODDIR/lib/backend.sh" || {
  printf 'boot: failed to source lib/backend.sh\n' >> "$BOOT_MARKER" 2>/dev/null || true
  exit 0
}

start_ctld
backend_log INFO BOOT_SERVICE_EXECUTED

i=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != 1 ] && [ "$i" -lt 300 ]; do
  sleep 1
  i=$((i + 1))
done
printf 'boot: boot_completed=%s waited=%ss\n' \
  "$(getprop sys.boot_completed 2>/dev/null)" "$i" >> "$BOOT_MARKER" 2>/dev/null || true
[ "$i" -ge 300 ] && backend_log WARN BOOT_WAIT_TIMEOUT

boot_try_start() {
  start_rc=1
  if ! backend_lock_acquire; then
    [ -n "${BACKEND_ERROR:-}" ] || BACKEND_ERROR=E_BUSY
    return 1
  fi
  backend_start
  start_rc=$?
  backend_lock_release
  return "$start_rc"
}

boot_log_failure() {
  backend_log ERROR "BOOT_START_FAILED_${BACKEND_ERROR:-E_UNKNOWN}"
  printf 'boot: start failed error=%s rc=%s at %s\n' \
    "${BACKEND_ERROR:-E_UNKNOWN}" "${start_rc:-?}" \
    "$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null)" >> "$BOOT_MARKER" 2>/dev/null || true
}

retry_delays='5 5 10 10 15 15 30 30 30 60 60 60 120 120 120 120'
if [ "${ROOTSMB_TEST_MODE:-0}" = 1 ] && [ -n "${ROOTSMB_TEST_BOOT_RETRY_DELAYS+x}" ]; then
  retry_delays=$ROOTSMB_TEST_BOOT_RETRY_DELAYS
fi

if boot_try_start; then
  backend_log INFO BOOT_START_OK
  printf 'boot: started successfully at %s\n' \
    "$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null)" >> "$BOOT_MARKER" 2>/dev/null || true
  exit 0
fi
boot_log_failure
case "${BACKEND_ERROR:-E_START}" in
  E_BIND|E_START|E_BUSY|E_PATH) ;;
  *) backend_log ERROR BOOT_START_FAILED; exit 0 ;;
esac

for retry_delay in $retry_delays; do
  backend_log INFO BOOT_START_RETRY
  sleep "$retry_delay"
  if boot_try_start; then
    backend_log INFO BOOT_START_OK
    printf 'boot: started successfully after retry %ss at %s\n' \
      "$retry_delay" "$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null)" >> "$BOOT_MARKER" 2>/dev/null || true
    exit 0
  fi
  boot_log_failure
  case "${BACKEND_ERROR:-E_START}" in
    E_BIND|E_START|E_BUSY|E_PATH) ;;
    *) backend_log ERROR BOOT_START_FAILED; exit 0 ;;
  esac
done

backend_log ERROR BOOT_START_FAILED
printf 'boot: gave up after all retries at %s\n' \
  "$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null)" >> "$BOOT_MARKER" 2>/dev/null || true
exit 0
