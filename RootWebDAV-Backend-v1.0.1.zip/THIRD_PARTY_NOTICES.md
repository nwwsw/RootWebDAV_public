# Third-party notices

## Samba `smbd`

`bin/smbd` is copied unchanged from
[`YAWAsau/Android-_SMB_For_KSU`](https://github.com/YAWAsau/Android-_SMB_For_KSU),
tag `0.3.11`, commit `fea1105f86238f8f1592ee1e76355bf616e20e6a`.

- Reported version: Samba 4.24.4
- Target: Android arm64-v8a only
- Size: 13,844,688 bytes
- SHA-256: `F9BE4CE24641F6CBF99226524698726A0DA75276EF1AC275B57B5FE2EA34DC23`
- Upstream module author: Github@YAWAsau

Samba components are distributed under GPL-3.0-or-later and/or
LGPL-3.0-or-later terms as applicable. The accompanying `LICENSE` contains the
GNU GPL version 3 text copied from the upstream module.

Important: the upstream module repository does not contain the corresponding
Samba source tree, patches, or reproducible build instructions for this exact
binary. The binary is therefore treated as an opaque, checksum-pinned artifact.
Before publicly redistributing the ZIP, the distributor must obtain and provide
the complete corresponding source and all other materials required by the
applicable Samba licenses. A checksum and a license copy do not replace that
obligation.

No other upstream native helper (`ntlmhash`, `netwatch`, or `propwait`) and no
upstream WebUI/Dex file is included. Password hashing in this module is new
shell source that reads the RPC payload only from stdin.

