#!/system/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later

MODDIR=${0%/*}
CONTROL=$MODDIR/bin/smbctl

[ -r "$CONTROL" ] || exit 0

json_str() {
  sed -n "s/.*\"$1\":\"\([^\"]*\)\".*/\1/p" | head -n 1
}

if printf 'ROOTSMB/1\nOP=status\nEND\n' | sh "$CONTROL" rpc 2>/dev/null | grep -q '"running":true'; then
  printf 'ROOTSMB/1\nOP=stop\nEND\n' | sh "$CONTROL" rpc >/dev/null 2>&1
  echo "RootWebDAV: 已关闭"
  exit 0
fi

REPLY=$(printf 'ROOTSMB/1\nOP=start\nEND\n' | sh "$CONTROL" rpc 2>/dev/null)
case "$REPLY" in
  *'"running":true'*|*'"ok":true'*)
    echo "RootWebDAV: 已开启"
    STATUS=$(printf 'ROOTSMB/1\nOP=status\nEND\n' | sh "$CONTROL" rpc 2>/dev/null)
    LOAD=$(printf 'ROOTSMB/1\nOP=load\nEND\n' | sh "$CONTROL" rpc 2>/dev/null)
    ADDRS=$(printf '%s' "$STATUS" | json_str addresses)
    PORT=$(printf '%s' "$STATUS" | sed -n 's/.*"port":\([0-9][0-9]*\).*/\1/p' | head -n 1)
    IP=${ADDRS%%,*}
    [ -n "$IP" ] || IP=$(printf '%s' "$STATUS" | json_str host)
    USER=$(printf '%s' "$LOAD" | json_str username)
    PASS=$(printf '%s' "$LOAD" | json_str password)
    PATHV=$(printf '%s' "$LOAD" | json_str sharePath)
    echo "地址: http://${IP:-无}:${PORT:-8080}/"
    echo "用户名: ${USER:-nwwsw}"
    echo "密码: ${PASS:-未设置}"
    echo "目录: ${PATHV:-未设置}"
    ;;
  *) echo "RootWebDAV: 启动失败" ;;
esac
